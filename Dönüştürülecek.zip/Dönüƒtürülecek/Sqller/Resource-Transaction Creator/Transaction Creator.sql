--VpTransaction 
 SELECT Replace('IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = '''+A.[TransactionName]+''')
BEGIN 
INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],
[IsFinancial]
,[IsInquiry],[HostGroupType]
,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])
VALUES('''+ISNULL(A.[TransactionName],'')+''','''+
ISNULL(REPLACE(A.[Description],'''',''''''),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.[TransactionTypeId]),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.[IsFinancial]),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.[IsInquiry]),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.[HostGroupType]),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.[isCross]),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.[isLead]),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.[isVirtual]),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.IsInternetBankingTransaction),'NULL')+''','''+
ISNULL(CONVERT(NVARCHAR,A.IsTransactionBasedLoggingEnabled),'NULL')+''')
END','''NULL''','NULL') as SQLTEXT 
from VpTransaction A 
where A.ID IN (1151 )
--VpTransaction25962 Attributes
select REPLACE('IF NOT EXISTS (select * from VpTransactionAttributes where 
ChannelID = '+CONVERT(NVARCHAR,A.ChannelID)+' and 
TransactionID = 
(select ID from VpTransaction where TransactionName = '''+(select TransactionName from VpTransaction where ID = A.TransactionID)+'''))
BEGIN
INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,
IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)
VALUES((select ID from VpTransaction where TransactionName = '''+(select TransactionName from VpTransaction where ID = A.TransactionID)+'''),
'+ISNULL(CONVERT(NVARCHAR,A.ChannelID),'NULL')+',
'+ISNULL(CONVERT(NVARCHAR,A.IsDeleted),'NULL')+',
'+ISNULL(CONVERT(NVARCHAR,A.IsOTPRequired),'NULL')+',
'''+ISNULL(CONVERT(NVARCHAR,A.FraudType),'NULL')+''',
'+ISNULL(CONVERT(NVARCHAR,A.IsHistoryLoggingEnabled),'NULL')+'
,'+ISNULL(CONVERT(NVARCHAR,A.LoggingVerbosity),'NULL')+',
'+ISNULL(CONVERT(NVARCHAR,A.IsPerformanceCounterEnabled),'NULL')+',
'+ISNULL(CONVERT(NVARCHAR,A.IsEnabled),'NULL')+',
'''+ISNULL(CONVERT(NVARCHAR,A.FraudState),'NULL')+''',
'+ISNULL(CONVERT(NVARCHAR,A.HostCallLogVerbosity),'NULL')+',
'''+ISNULL(CONVERT(NVARCHAR,A.HostProcessCode),'NULL')+''',
'''+ISNULL(CONVERT(NVARCHAR(max),REPLACE(A.DescriptionForChannel,'''','''''')),'NULL')+''')
END','''NULL''','NULL') as SQLTEXT
from VpTransactionAttributes  A 
where ChannelID = 2
and A.transactionID IN (1151)


--VpTransactionConfig
select 'IF NOT EXISTS(select * from VpTransactionConfig where 
ChannelID = '+CONVERT(NVARCHAR,A.ChannelID)+' and 
TransactionID = 
(select ID from VpTransaction where TransactionName = '''+(select C.TransactionName from VpTransaction C where C.ID = A.TransactionID)+'''))
BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)
VALUES((select ID from VpTransaction where TransactionName = '''+(select B.TransactionName from VpTransaction B where B.ID = A.TransactionID)+'''),'''+REPLACE(A.Configuration,'''','''''')+''',
'+ISNULL(CONVERT(NVARCHAR,A.ChannelProductOID),'NULL')+',getdate(),'''+A.CreateBy+''','+CONVERT(NVARCHAR,A.ChannelID)+') END'
from VpTransactionConfig A
where ChannelID = 2
and A.TransactionID IN (1151)

