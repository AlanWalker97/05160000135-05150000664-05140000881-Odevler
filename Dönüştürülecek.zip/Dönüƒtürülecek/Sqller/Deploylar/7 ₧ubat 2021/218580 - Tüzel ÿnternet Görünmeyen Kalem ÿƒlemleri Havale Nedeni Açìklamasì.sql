IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = 'GetRemittanceProcessDocument')  BEGIN   INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],  [IsFinancial]  ,[IsInquiry],[HostGroupType]  ,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])  VALUES('GetRemittanceProcessDocument','GetRemittanceProcessDocument',NULL,'0',NULL,NULL,NULL,'0',NULL,NULL,NULL)  END

IF NOT EXISTS (select * from VpTransactionAttributes where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetRemittanceProcessDocument'))  BEGIN  INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,  IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)  VALUES((select ID from VpTransaction where TransactionName = 'GetRemittanceProcessDocument'),  19,  0,  0,  NULL,  1  ,1111,  NULL,  1,  NULL,  11,  NULL,  'Get RemittanceProcessDocument')  END

IF NOT EXISTS(select * from VpTransactionConfig where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetRemittanceProcessDocument'))  BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)  VALUES((select ID from VpTransaction where TransactionName = 'GetRemittanceProcessDocument'),'<?xml version="1.0" encoding="utf-8" ?>                  <TransactionConfig   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"   xmlns="http://tempuri.org/VeriBranchMessages.xsd"><ImplementationData>  <RequestType>VeriBranch.Common.MessageDefinitions.GetRemittanceProcessDocumentRequest,VeriBranch.Common.MessageDefinitions</RequestType>  <ResponseType>VeriBranch.Common.MessageDefinitions.GetRemittanceProcessDocumentResponse,VeriBranch.Common.MessageDefinitions</ResponseType>  <ClassType>Finansbank.Business.Transactions.HostIntegrationTransaction,Finansbank.Business.Transactions</ClassType></ImplementationData>                  <Name>GetRemittanceProcessDocument</Name>                  <Simulate>false</Simulate></TransactionConfig>',  NULL,getdate(),'T64513',19) END

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='NecessaryDocumentInfoText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','NecessaryDocumentInfoText','İşlemlerinizin devam edebilmesi için, seçtiğiniz havale nedenine karşılık aşağıdaki belgeleri yüklemeniz gerekmektedir:<br>','NecessaryDocumentInfoText',NULL,NULL,1,'Jan 18 2021  3:10PM',NULL,NULL,'T64513','Jan 18 2021  3:10PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlemlerinizin devam edebilmesi için, seçtiğiniz havale nedenine karşılık aşağıdaki belgeleri yüklemeniz gerekmektedir:<br>'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='NecessaryDocumentInfoText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='NecessaryDocumentInfoText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','NecessaryDocumentInfoText','In order for your transactions to continue, you need to upload the following documents for the transfer reason you have chosen:<br>','NecessaryDocumentInfoText',NULL,NULL,1,'Jan 18 2021  3:10PM',NULL,NULL,'T64513','Jan 18 2021  3:10PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='In order for your transactions to continue, you need to upload the following documents for the transfer reason you have chosen:<br>'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='NecessaryDocumentInfoText' and ChannelId=19 
	end


if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='NecessaryDocumentInfoLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','NecessaryDocumentInfoLabel.Text','Bilgilendirme','NecessaryDocumentInfoLabel.Text',NULL,NULL,1,'Jan 18 2021  3:10PM',NULL,NULL,'T64513','Jan 18 2021  3:10PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bilgilendirme'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='NecessaryDocumentInfoLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='NecessaryDocumentInfoLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','NecessaryDocumentInfoLabel.Text','Information','NecessaryDocumentInfoLabel.Text',NULL,NULL,1,'Jan 18 2021  3:10PM',NULL,NULL,'T64513','Jan 18 2021  3:10PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Information'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='NecessaryDocumentInfoLabel.Text' and ChannelId=19 
	end