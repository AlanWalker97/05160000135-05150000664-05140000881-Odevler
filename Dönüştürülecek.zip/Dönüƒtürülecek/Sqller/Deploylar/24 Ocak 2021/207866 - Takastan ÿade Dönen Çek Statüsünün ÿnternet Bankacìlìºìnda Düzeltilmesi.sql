if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='PaidCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','tr-TR','PaidCheque','Ödenmiş Çek','Ödenmiş Çek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ödenmiş Çek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='PaidCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='PaidCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','en-US','PaidCheque','Ödenmiş Çek','Ödenmiş Çek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ödenmiş Çek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='PaidCheque' and ChannelId=19 
	end

------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='BouncedCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','tr-TR','BouncedCheque','Karşılıksız Çek','Karşılıksız Çek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Karşılıksız Çek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='BouncedCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='BouncedCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','en-US','BouncedCheque','Karşılıksız Çek','Karşılıksız Çek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Karşılıksız Çek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='BouncedCheque' and ChannelId=19 
	end

--------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='MistakenCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','tr-TR','MistakenCheque','Hatalı Çek','Hatalı Çek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hatalı Çek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='MistakenCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='MistakenCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','en-US','MistakenCheque','Hatalı Çek','Hatalı Çek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hatalı Çek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='MistakenCheque' and ChannelId=19 
	end

----------------------------



if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='CourtBannedCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','tr-TR','CourtBannedCheque','Mahkeme Ödeme Yasaklı','Mahkeme Ödeme Yasaklı',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Mahkeme Ödeme Yasaklı'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='CourtBannedCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='CourtBannedCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','en-US','CourtBannedCheque','Mahkeme Ödeme Yasaklı','Mahkeme Ödeme Yasaklı',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Mahkeme Ödeme Yasaklı'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='CourtBannedCheque' and ChannelId=19 
	end

----------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='MistakenCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','MistakenCheque','Hatalı Çek','Hatalı Çek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hatalı Çek'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='MistakenCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='MistakenCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','MistakenCheque','Hatalı Çek','Hatalı Çek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hatalı Çek'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='MistakenCheque' and ChannelId=19 
	end

----------------------------