if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentDetailGridViewBcBillNumber.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx','tr-TR','PaymentDetailGridViewBcBillNumber.HeaderText','Fatura Numarası','Fatura Numarası',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Fatura Numarası'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentDetailGridViewBcBillNumber.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='en-US' and ResourceKey='PaymentDetailGridViewBcBillNumber.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx','en-US','PaymentDetailGridViewBcBillNumber.HeaderText','Fatura Numarası','Fatura Numarası',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Fatura Numarası'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='en-US' and ResourceKey='PaymentDetailGridViewBcBillNumber.HeaderText' and ChannelId=19 
	end





	if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentDetailGridViewBcReceiverSwiftCode.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx','tr-TR','PaymentDetailGridViewBcReceiverSwiftCode.HeaderText','Alıcı Swift Kodu','Alıcı Swift Kodu',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Alıcı Swift Kodu'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentDetailGridViewBcReceiverSwiftCode.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='en-US' and ResourceKey='PaymentDetailGridViewBcReceiverSwiftCode.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx','en-US','PaymentDetailGridViewBcReceiverSwiftCode.HeaderText','Alıcı Swift Kodu','Alıcı Swift Kodu',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Fatura Numarası'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='en-US' and ResourceKey='PaymentDetailGridViewBcReceiverSwiftCode.HeaderText' and ChannelId=19 
	end





	if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ReceiverSwiftCode' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ReceiverSwiftCode','Alıcı Swift Kodu','Alıcı Swift Kodu :',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Alıcı Swift Kodu'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ReceiverSwiftCode' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ReceiverSwiftCode' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ReceiverSwiftCode','Alıcı Swift Kodu','Alıcı Swift Kodu :',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Alıcı Swift Kodu'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ReceiverSwiftCode' and ChannelId=19 
	end
