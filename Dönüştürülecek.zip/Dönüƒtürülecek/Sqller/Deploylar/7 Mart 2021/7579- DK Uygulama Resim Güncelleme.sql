update VpStringResource set ResourceValue='eFinans_01.jpg' where ResourceKey='QNBEFINANS_ServiceMainImageName'
update VpStringResource set ResourceValue='eFinans_01.jpg' where ResourceKey='QNBEFINANS_ServiceDetailImageName1'
update VpStringResource set ResourceValue='eFinans_02.jpg' where ResourceKey='QNBEFINANS_ServiceDetailImageName2'
update VpStringResource set ResourceValue='eFinans_03.jpg' where ResourceKey='QNBEFINANS_ServiceDetailImageName3'

update VpStringResource set ResourceValue='KolayIK_1.png' where ResourceKey='KOLAYIK_ServiceMainImageName'
update VpStringResource set ResourceValue='KolayIK_1.png' where ResourceKey='KOLAYIK_ServiceDetailImageName1'
update VpStringResource set ResourceValue='KolayIK_2.png' where ResourceKey='KOLAYIK_ServiceDetailImageName2'
update VpStringResource set ResourceValue='KolayIK_3.png' where ResourceKey='KOLAYIK_ServiceDetailImageName3'

update VpStringResource set ResourceValue='ikas_01.jpg' where ResourceKey='ikas_ServiceMainImageName'
update VpStringResource set ResourceValue='ikas_01.jpg' where ResourceKey='ikas_ServiceDetailImageName1'
update VpStringResource set ResourceValue='ikas_02.jpg' where ResourceKey='ikas_ServiceDetailImageName2'
update VpStringResource set ResourceValue='ikas_03.jpg' where ResourceKey='ikas_ServiceDetailImageName3'

update VpStringResource set ResourceValue='navlungo_01.jpg' where ResourceKey='navlungo_ServiceMainImageName'
update VpStringResource set ResourceValue='navlungo_01.jpg' where ResourceKey='navlungo_ServiceDetailImageName1'
update VpStringResource set ResourceValue='navlungo_02.jpg' where ResourceKey='navlungo_ServiceDetailImageName2'
update VpStringResource set ResourceValue='navlungo_03.jpg' where ResourceKey='navlungo_ServiceDetailImageName3'

update VpStringResource set ResourceValue='KolayBi_01.jpg' where ResourceKey='KOLAYBI_ServiceMainImageName'
update VpStringResource set ResourceValue='KolayBi_01.jpg' where ResourceKey='KOLAYBI_ServiceDetailImageName1'
update VpStringResource set ResourceValue='KolayBi_02.jpg' where ResourceKey='KOLAYBI_ServiceDetailImageName2'
update VpStringResource set ResourceValue='KolayBi_03.jpg' where ResourceKey='KOLAYBI_ServiceDetailImageName3'

update VpStringResource set ResourceValue='KolayBi_01.jpg' where ResourceKey='NKOLAYOFIS_ServiceMainImageName'
update VpStringResource set ResourceValue='KolayBi_01.jpg' where ResourceKey='NKOLAYOFIS_ServiceDetailImageName1'
update VpStringResource set ResourceValue='KolayBi_02.jpg' where ResourceKey='NKOLAYOFIS_ServiceDetailImageName2'
update VpStringResource set ResourceValue='KolayBi_03.jpg' where ResourceKey='NKOLAYOFIS_ServiceDetailImageName3'

---------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='DashboardPage' and CultureCode='tr-TR' and ResourceKey='WelcomeText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('DashboardPage','tr-TR','WelcomeText','Hoş geldiniz',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Feb  16 2021  11:58AM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hoş geldiniz'
			where ResourceType='DashboardPage' and CultureCode='tr-TR' and ResourceKey='WelcomeText' and ChannelId=55 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='DashboardPage' and CultureCode='en-US' and ResourceKey='WelcomeText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('DashboardPage','en-US','WelcomeText','Hoş geldiniz',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Feb  16 2021  11:58AM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hoş geldiniz'
			where ResourceType='DashboardPage' and CultureCode='en-US' and ResourceKey='WelcomeText' and ChannelId=55 
	end

---------------------

IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = 'ImageManagementTransaction')  BEGIN   INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],  [IsFinancial]  ,[IsInquiry],[HostGroupType]  ,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])  VALUES('ImageManagementTransaction','İmaj Yönetimi İşlem',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)  END

IF NOT EXISTS (select * from VpTransactionAttributes where   ChannelID = 2 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'ImageManagementTransaction'))  BEGIN  INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,  IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)  VALUES((select ID from VpTransaction where TransactionName = 'ImageManagementTransaction'),  2,  0,  0,  NULL,  1  ,1111,  NULL,  1,  NULL,  11,  NULL,  'İmaj Yönetimi İşlem')  END

IF NOT EXISTS(select * from VpTransactionConfig where   ChannelID = 2 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'ImageManagementTransaction'))  BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)  VALUES((select ID from VpTransaction where TransactionName = 'ImageManagementTransaction'),'<?xml version="1.0" encoding="utf-8" ?><TransactionConfig xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://tempuri.org/VeriBranchMessages.xsd">  <Name>LogoManagementTransaction</Name>  <Simulate>false</Simulate>  <TransactionFlow>    <Step Name="Start" Action="RedirectToPage" Url="~/EnrollmentTransactions/ImageManagement/ImageManagement.aspx"></Step>  </TransactionFlow>  <ImplementationData>    <RequestType>VeriBranch.Common.MessageDefinitions.LogoManagementRequest, VeriBranch.Common.MessageDefinitions</RequestType>    <ResponseType>VeriBranch.Common.MessageDefinitions.LogoManagementResponse, VeriBranch.Common.MessageDefinitions</ResponseType>  <ClassType>Finansbank.Business.BackOffice.Transactions.ImageManagementTransaction, Finansbank.Business.BackOffice.Transactions</ClassType>  </ImplementationData> </TransactionConfig>',  NULL,getdate(),'T64513',2) END


IF NOT EXISTS(select * from VpMenu where Title = 'İmaj Yönetimi') BEGIN INSERT INTO [VpMenu]([ParentID],[MenuID],[MenuActionTypeID],[Title],[EnTitle],[Description],[OperationCode],[IsTransaction],[Url],[JavaScript],[IsTrimmingEnabled],[OrderIndex],[CssClass],[EnCssClass],[HostProcessCode],[ShowInTurkish],[ShowInEnglish],[MenuNickName],[EnMenuNickname],[MenuTooltip],[EnMenuTooltip],[MenuKeywords],[EnMenuKeywords],[ProductBadgeName],[EnProductBadgeName],[Roles],[IsBackOfficeMenu],[ChannelID],[ColorCode],[NewFlagExpireDate]) VALUES((select ParentID from VpMenu where Title='İçerik Yönetimi' and ChannelID=55),(select MenuID from VpMenu where Title='İçerik Yönetimi' and ChannelID=55),(select MenuActionTypeID from VpMenu where Title='İçerik Yönetimi' and ChannelID=55),'İmaj Yönetimi','','İmaj Yönetimi',NULL,0,'~/NavigationController.aspx?page=ImageManagementTransaction',NULL,0,0,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'*',1,55,NULL,NULL) END

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_Success' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','STR_Success','İşleminiz Başarıyla Gerçekleştirildi.','İşleminiz Başarıyla Gerçekleştirildi.',NULL,'',1,NULL,NULL,NULL,NULL,'Feb 27 2021  8:17PM','Feb 27 2021  8:17PM','0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşleminiz Başarıyla Gerçekleştirildi.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_Success' and ChannelId=2 
	end

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_ImageUploadError' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','STR_ImageUploadError','İmaj yükleme sırasında hata oluştu!','İmaj yükleme sırasında hata oluştu!',NULL,'',1,NULL,NULL,NULL,NULL,'Feb 27 2021  8:17PM','Feb 27 2021  8:17PM','0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İmaj yükleme sırasında hata oluştu!'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_ImageUploadError' and ChannelId=2 
	end

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_EmptyError' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','STR_EmptyError','Lütfen tüm alanları doldurunuz.','Lütfen tüm alanları doldurunuz.',NULL,'',1,NULL,NULL,NULL,NULL,'Feb 27 2021  8:17PM','Feb 27 2021  8:17PM','0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen tüm alanları doldurunuz.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_EmptyError' and ChannelId=2 
	end

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_AlreadyExists' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','STR_AlreadyExists','Bu isimde bir imaj bulunduğu için bu imaj kaydedilemez. Eğer mevcuttaki imajı değişirmek istiyorsanız güncellemeniz gerekmektedir.','Bu isimde bir imaj bulunduğu için bu imaj kaydedilemez. Eğer mevcuttaki imajı değişirmek istiyorsanız güncellemeniz gerekmektedir.',NULL,'',1,NULL,NULL,NULL,NULL,'Feb 27 2021  8:17PM','Feb 27 2021  8:17PM','0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bu isimde bir imaj bulunduğu için bu imaj kaydedilemez. Eğer mevcuttaki imajı değişirmek istiyorsanız güncellemeniz gerekmektedir.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_AlreadyExists' and ChannelId=2 
	end

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_ForbiddenName' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','STR_ForbiddenName','İmaj için belirtmiş olduğunuz isimde yasaklı bir kelime ({0}) bulunmaktadır, lütfen farklı bir isim seçin.','İmaj için belirtmiş olduğunuz isimde yasaklı bir kelime ({0}) bulunmaktadır, lütfen farklı bir isim seçin.',NULL,'',1,NULL,NULL,NULL,NULL,'Feb 27 2021  8:17PM','Feb 27 2021  8:17PM','0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İmaj için belirtmiş olduğunuz isimde yasaklı bir kelime ({0}) bulunmaktadır, lütfen farklı bir isim seçin.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='STR_ForbiddenName' and ChannelId=2 
	end