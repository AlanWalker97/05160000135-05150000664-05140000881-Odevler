if not Exists(select 1 from vpStringResource(nolock) where ResourceType='MenuComponent' and CultureCode='tr-TR' and ResourceKey='mainPageTooltipText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('MenuComponent','tr-TR','mainPageTooltipText','Ana Sayfa',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Oct 21 2020  2:34PM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ana Sayfa'
			where ResourceType='MenuComponent' and CultureCode='tr-TR' and ResourceKey='mainPageTooltipText' and ChannelId=55 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='MenuComponent' and CultureCode='en-US' and ResourceKey='mainPageTooltipText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('MenuComponent','en-US','mainPageTooltipText','Main Menu',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Oct 21 2020  2:34PM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Main Menu'
			where ResourceType='MenuComponent' and CultureCode='en-US' and ResourceKey='mainPageTooltipText' and ChannelId=55 
	end

--------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='MenuComponent' and CultureCode='tr-TR' and ResourceKey='marketPlaceTooltipText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('MenuComponent','tr-TR','marketPlaceTooltipText','Marketplace',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Oct 21 2020  2:34PM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Marketplace'
			where ResourceType='MenuComponent' and CultureCode='tr-TR' and ResourceKey='marketPlaceTooltipText' and ChannelId=55 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='MenuComponent' and CultureCode='en-US' and ResourceKey='marketPlaceTooltipText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('MenuComponent','en-US','marketPlaceTooltipText','Marketplace',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Oct 21 2020  2:34PM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Marketplace'
			where ResourceType='MenuComponent' and CultureCode='en-US' and ResourceKey='marketPlaceTooltipText' and ChannelId=55 
	end


--------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='MenuComponent' and CultureCode='tr-TR' and ResourceKey='settingsTooltipText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('MenuComponent','tr-TR','settingsTooltipText','Ayarlar',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Oct 21 2020  2:34PM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ayarlar'
			where ResourceType='MenuComponent' and CultureCode='tr-TR' and ResourceKey='settingsTooltipText' and ChannelId=55 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='MenuComponent' and CultureCode='en-US' and ResourceKey='settingsTooltipText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('MenuComponent','en-US','settingsTooltipText','Settings',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Oct 21 2020  2:34PM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Settings'
			where ResourceType='MenuComponent' and CultureCode='en-US' and ResourceKey='settingsTooltipText' and ChannelId=55 
	end

--------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='MenuComponent' and CultureCode='tr-TR' and ResourceKey='logoutTooltipText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('MenuComponent','tr-TR','logoutTooltipText','Güvenli Çıkış',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Oct 21 2020  2:34PM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Güvenli Çıkış'
			where ResourceType='MenuComponent' and CultureCode='tr-TR' and ResourceKey='logoutTooltipText' and ChannelId=55 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='MenuComponent' and CultureCode='en-US' and ResourceKey='logoutTooltipText' and ChannelId=55) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('MenuComponent','en-US','logoutTooltipText','Safe Logout',NULL,NULL,NULL,1,NULL,NULL,NULL,'T64513','Oct 21 2020  2:34PM',NULL,'0',NULL,'55') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Safe Logout'
			where ResourceType='MenuComponent' and CultureCode='en-US' and ResourceKey='logoutTooltipText' and ChannelId=55 
	end

---------------------------
update VpStringResource set ResourceValue='Dijital Köprü Dükkan' where ResourceKey='marketPlaceTooltipText' and ChannelID='55'

update VpStringResource set ResourceValue='Profil ve Ayarlar' where ResourceKey='settingsTooltipText' and ChannelID='55'