--VpTransaction-Attribute-Config (ForeignTradeIncomingSwiftTransaction)--
IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = 'ForeignTradeIncomingSwiftTransaction')  BEGIN   INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],  [IsFinancial]  ,[IsInquiry],[HostGroupType]  ,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])  VALUES('ForeignTradeIncomingSwiftTransaction','Gelen SWIFT Gözlem',NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL)  END

IF NOT EXISTS (select * from VpTransactionAttributes where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'ForeignTradeIncomingSwiftTransaction'))  BEGIN  INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,  IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)  VALUES((select ID from VpTransaction where TransactionName = 'ForeignTradeIncomingSwiftTransaction'),  19,  0,  0,  NULL,  1  ,1111,  NULL,  1,  NULL,  11,  '101200',  'Gelen SWIFT Gözlem')  END

IF NOT EXISTS(select * from VpTransactionConfig where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'ForeignTradeIncomingSwiftTransaction'))  BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)  VALUES((select ID from VpTransaction where TransactionName = 'ForeignTradeIncomingSwiftTransaction'),'<?xml version="1.0" encoding="utf-8" ?>  <TransactionConfig   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"   xmlns:xsd="http://www.w3.org/2001/XMLSchema"   xmlns="http://tempuri.org/VeriBranchMessages.xsd">    <TransactionFlow>      <Step Name="Start" Action = "RedirectToPage" Url = "~/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx" StepNameResourceKey = "Start"></Step>    </TransactionFlow>    <ImplementationData>      <RequestType>VeriBranch.Common.MessageDefinitions.DummyRequest, VeriBranch.Common.MessageDefinitions</RequestType>      <ResponseType>VeriBranch.Common.MessageDefinitions.DummyResponse, VeriBranch.Common.MessageDefinitions</ResponseType>      <ClassType>Finansbank.Business.Transactions.HostIntegrationTransaction, Finansbank.Business.Transactions</ClassType>    </ImplementationData>    <Name>ForeignTradeIncomingSwiftTransaction</Name>    <Simulate>false</Simulate>  </TransactionConfig>',  NULL,getdate(),'T64513',19) END
--VpTransaction-Attribute-Config (ForeignTradeIncomingSwiftTransaction)--

--VpTransaction-Attribute-Config (ListSwiftInboundRecord)--
IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = 'ListSwiftInboundRecord')  BEGIN   INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],  [IsFinancial]  ,[IsInquiry],[HostGroupType]  ,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])  VALUES('ListSwiftInboundRecord','ListSwiftInboundRecord',NULL,'0',NULL,NULL,NULL,'0',NULL,NULL,NULL)  END

IF NOT EXISTS (select * from VpTransactionAttributes where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'ListSwiftInboundRecord'))  BEGIN  INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,  IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)  VALUES((select ID from VpTransaction where TransactionName = 'ListSwiftInboundRecord'),  19,  0,  0,  NULL,  1  ,1111,  NULL,  1,  NULL,  11,  NULL,  'List SwiftInboundRecord')  END

IF NOT EXISTS(select * from VpTransactionConfig where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'ListSwiftInboundRecord'))  BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)  VALUES((select ID from VpTransaction where TransactionName = 'ListSwiftInboundRecord'),'<?xml version="1.0" encoding="utf-8" ?>                  <TransactionConfig   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"   xmlns="http://tempuri.org/VeriBranchMessages.xsd"><ImplementationData>  <RequestType>VeriBranch.Common.MessageDefinitions.ListSwiftInboundRecordRequest,VeriBranch.Common.MessageDefinitions</RequestType>  <ResponseType>VeriBranch.Common.MessageDefinitions.ListSwiftInboundRecordResponse,VeriBranch.Common.MessageDefinitions</ResponseType>  <ClassType>Finansbank.Business.Transactions.HostIntegrationTransaction,Finansbank.Business.Transactions</ClassType></ImplementationData>                  <Name>ListSwiftInboundRecord</Name>                  <Simulate>false</Simulate></TransactionConfig>',  NULL,getdate(),'T64513',19) END
--VpTransaction-Attribute-Config (ListSwiftInboundRecord)--

--VpTransaction-Attribute-Config (GetSwiftInboundRecordHistory)--
IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = 'GetSwiftInboundRecordHistory')  BEGIN   INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],  [IsFinancial]  ,[IsInquiry],[HostGroupType]  ,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])  VALUES('GetSwiftInboundRecordHistory','GetSwiftInboundRecordHistory',NULL,'0',NULL,NULL,NULL,'0',NULL,NULL,NULL)  END

IF NOT EXISTS (select * from VpTransactionAttributes where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetSwiftInboundRecordHistory'))  BEGIN  INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,  IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)  VALUES((select ID from VpTransaction where TransactionName = 'GetSwiftInboundRecordHistory'),  19,  0,  0,  NULL,  1  ,1111,  NULL,  1,  NULL,  11,  NULL,  'Get SwiftInboundRecordHistory')  END

IF NOT EXISTS(select * from VpTransactionConfig where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetSwiftInboundRecordHistory'))  BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)  VALUES((select ID from VpTransaction where TransactionName = 'GetSwiftInboundRecordHistory'),'<?xml version="1.0" encoding="utf-8" ?>                  <TransactionConfig   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"   xmlns="http://tempuri.org/VeriBranchMessages.xsd"><ImplementationData>  <RequestType>VeriBranch.Common.MessageDefinitions.GetSwiftInboundRecordHistoryRequest,VeriBranch.Common.MessageDefinitions</RequestType>  <ResponseType>VeriBranch.Common.MessageDefinitions.GetSwiftInboundRecordHistoryResponse,VeriBranch.Common.MessageDefinitions</ResponseType>  <ClassType>Finansbank.Business.Transactions.HostIntegrationTransaction,Finansbank.Business.Transactions</ClassType></ImplementationData>                  <Name>GetSwiftInboundRecordHistory</Name>                  <Simulate>false</Simulate></TransactionConfig>',  NULL,getdate(),'T64513',19) END
--VpTransaction-Attribute-Config (GetSwiftInboundRecordHistory)--

--VpMenuGirdisi
IF NOT EXISTS(select * from VpMenu where Title = 'Gelen SWIFT Gözlem') BEGIN INSERT INTO [VpMenu]([ParentID],[MenuID],[MenuActionTypeID],[Title],[EnTitle],[Description],[OperationCode],[IsTransaction],[Url],[JavaScript],[IsTrimmingEnabled],[OrderIndex],[CssClass],[EnCssClass],[HostProcessCode],[ShowInTurkish],[ShowInEnglish],[MenuNickName],[EnMenuNickname],[MenuTooltip],[EnMenuTooltip],[MenuKeywords],[EnMenuKeywords],[ProductBadgeName],[EnProductBadgeName],[Roles],[IsBackOfficeMenu],[ChannelID],[ColorCode],[NewFlagExpireDate]) VALUES((select ParentID from VpMenu where Title='Kazanan KOBİ' and ChannelID=19),(select MenuID from VpMenu where Title='Kazanan KOBİ' and ChannelID=19),(select MenuActionTypeID from VpMenu where Title='Kazanan KOBİ' and ChannelID=19),'Gelen SWIFT Gözlem','Incoming SWIFT Observation','Gelen SWIFT Gözlem','-',1,'ForeignTradeIncomingSwiftTransaction','-',0,11,NULL,NULL,'101200',1,1,'-','-','-','-','-','-','-','-','-',NULL,19,NULL,NULL) END
--VpMenuGirdisi

--VpStringResource--
---İşlem Kodları--
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSC' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ACSC','Gönderici Tarafından Başlatıldı','Gönderici Tarafından Başlatıldı',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gönderici Tarafından Başlatıldı'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSC' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSC' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ACSC','Started By Sender','Started By Sender',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Started By Sender'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSC' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACCC' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ACCC','Tamamlandı','Tamamlandı',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Tamamlandı'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACCC' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACCC' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ACCC','Completed','Completed',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Completed'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACCC' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT','Reddedildi','Reddedildi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT','Rejected','Rejected',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ACSP','Bankamıza Ulaştı','Bankamıza Ulaştı',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bankamıza Ulaştı'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ACSP','Reached Our Bank','Reached Our Bank',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reached Our Bank'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP/G005' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ACSP/G005','Bankamıza Ulaştı','Bankamıza Ulaştı',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bankamıza Ulaştı'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP/G005' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP/G005' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ACSP/G005','Reached Our Bank','Reached Our Bank',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reached Our Bank'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP/G005' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP/G004' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ACSP/G004','Bankamıza Ulaştı - Ödeme Emri Bekleniyor','Bankamıza Ulaştı - Ödeme Emri Bekleniyor',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bankamıza Ulaştı - Ödeme Emri Bekleniyor'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP/G004' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP/G004' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ACSP/G004','Reached Our Bank - Awaiting Payment Order','Reached Our Bank - Awaiting Payment Order',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reached Our Bank - Awaiting Payment Order'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP/G004' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='PDNG' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','PDNG','Aracı Bankada Bekliyor','Aracı Bankada Bekliyor',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Aracı Bankada Bekliyor'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='PDNG' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='PDNG' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','PDNG','Waiting On The Intermediate Bank','Waiting On The Intermediate Bank',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Waiting On The Intermediate Bank'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='PDNG' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/AC01' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/AC01','Reddedildi / Hatalı Hesap Numarası','Reddedildi / Hatalı Hesap Numarası',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Hatalı Hesap Numarası'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/AC01' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/AC01' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/AC01','Rejected / Incorrect Account Number','Rejected / Incorrect Account Number',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Incorrect Account Number'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/AC01' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/AC04' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/AC04','Reddedildi / Kapalı Hesap','Reddedildi / Kapalı Hesap',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Kapalı Hesap'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/AC04' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/AC04' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/AC04','Rejected / Closed Account','Rejected / Closed Account',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Closed Account'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/AC04' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/AC06' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/AC06','Reddedildi / Bloke Hesap','Reddedildi / Bloke Hesap',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Bloke Hesap'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/AC06' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/AC06' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/AC06','Rejected / Blocked Account','Rejected / Blocked Account',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Blocked Account'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/AC06' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/BE01' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/BE01','Reddedildi / Alıcı Müşteriyle Uyumsuz','Reddedildi / Alıcı Müşteriyle Uyumsuz',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Alıcı Müşteriyle Uyumsuz'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/BE01' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/BE01' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/BE01','Rejected / Incompatible With Recepient Customer','Rejected / Incompatible With Recepient Customer',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Incompatible With Recepient Customer'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/BE01' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/NOAS' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/NOAS','Reddedildi / Müşteriden Yanıt Alınamadı','Reddedildi / Müşteriden Yanıt Alınamadı',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Müşteriden Yanıt Alınamadı'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/NOAS' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/NOAS' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/NOAS','Rejected / No Response From Customer','Rejected / No Response From Customer',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / No Response From Customer'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/NOAS' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/RR03' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/RR03','Reddedildi / Eksik Alıcı Unvan Veya Adresi','Reddedildi / Eksik Alıcı Unvan Veya Adresi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Eksik Alıcı Unvan Veya Adresi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/RR03' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/RR03' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/RR03','Rejected / Missing Recipient Title Or Address','Rejected / Missing Recipient Title Or Address',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Missing Recipient Title Or Address'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/RR03' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/FF07' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/FF07','Reddedildi','Reddedildi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/FF07' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/FF07' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/FF07','Rejected','Rejected',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/FF07' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/RC01' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/RC01','Reddedildi / Hatalı Banka Bilgisi','Reddedildi / Hatalı Banka Bilgisi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Hatalı Banka Bilgisi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/RC01' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/RC01' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/RC01','Rejected / Incorrect Bank Information','Rejected / Incorrect Bank Information',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Incorrect Bank Information'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/RC01' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/RC08' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/RC08','Reddedildi','Reddedildi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/RC08' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/RC08' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/RC08','Rejected','Rejected',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/RC08' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/FOCR' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/FOCR','Reddedildi / İptal Talebi Bulunuyor','Reddedildi / İptal Talebi Bulunuyor',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / İptal Talebi Bulunuyor'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/FOCR' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/FOCR' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/FOCR','Rejected / Cancellation Request Is Available','Rejected / Cancellation Request Is Available',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Cancellation Request Is Available'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/FOCR' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/RR05' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/RR05','Reddedildi','Reddedildi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/RR05' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/RR05' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/RR05','Rejected','Rejected',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/RR05' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/AM06' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/AM06','Reddedildi / Düşük Tutar','Reddedildi / Düşük Tutar',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Düşük Tutar'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/AM06' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/AM06' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/AM06','Rejected / Low Amount','Rejected / Low Amount',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Low Amount'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/AM06' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/CUST' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/CUST','Reddedildi / Müşteri Talebi','Reddedildi / Müşteri Talebi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Müşteri Talebi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/CUST' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/CUST' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/CUST','Rejected / Customer Request','Rejected / Customer Request',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Customer Request'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/CUST' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/MS03' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/MS03','Reddedildi / Banka Tarafından Belirtilmeyen Sebep','Reddedildi / Banka Tarafından Belirtilmeyen Sebep',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Banka Tarafından Belirtilmeyen Sebep'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/MS03' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/MS03' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/MS03','Rejected / Reason That Not Specified By The Bank','Rejected / Reason That Not Specified By The Bank',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Reason That Not Specified By The Bank'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/MS03' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP/G998' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ACSP/G998','Bankamıza Ulaştı / Muhabirden Ödeme Emri Bekleniyor','Bankamıza Ulaştı / Muhabirden Ödeme Emri Bekleniyor',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bankamıza Ulaştı / Muhabirden Ödeme Emri Bekleniyor'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP/G998' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP/G998' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ACSP/G998','Reached Our Bank / Awaiting Payment Order From Correspondent','Reached Our Bank / Awaiting Payment Order From Correspondent',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reached Our Bank / Awaiting Payment Order From Correspondent'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP/G998' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP/G999' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ACSP/G999','Bankamıza Ulaştı / İnceleniyor','Bankamıza Ulaştı / İnceleniyor',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bankamıza Ulaştı / İnceleniyor'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ACSP/G999' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP/G999' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ACSP/G999','Reached Our Bank / Under Examination','Reached Our Bank / Under Examination',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reached Our Bank / Under Examination'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ACSP/G999' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/DUPL' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','RJCT/DUPL','Reddedildi / Mükerrer İşlem','Reddedildi / Mükerrer İşlem',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Reddedildi / Mükerrer İşlem'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='RJCT/DUPL' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/DUPL' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','RJCT/DUPL','Rejected / Duplicate Transaction','Rejected / Duplicate Transaction',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rejected / Duplicate Transaction'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='RJCT/DUPL' and ChannelId=19 
	end
-----------------------
---Ana Ekran Resource--
-----------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='NavigationControllerTransactionTrackButtonCssClass' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','NavigationControllerTransactionTrackButtonCssClass','btn_islemTakibi','NavigationControllerTransactionTrackButtonCssClass',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='btn_islemTakibi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='NavigationControllerTransactionTrackButtonCssClass' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='NavigationControllerTransactionTrackButtonCssClass' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','NavigationControllerTransactionTrackButtonCssClass','btn_islemTakibi_EN','NavigationControllerTransactionTrackButtonCssClass',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='btn_islemTakibi_EN'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='NavigationControllerTransactionTrackButtonCssClass' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='CommonAdvice.Header.ForeignTradeIncomingSwiftTransaction.0' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','CommonAdvice.Header.ForeignTradeIncomingSwiftTransaction.0','Bu ekranı görüntüleme yetkiniz bulunmamaktadır.','Advice Page',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bu ekranı görüntüleme yetkiniz bulunmamaktadır.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='CommonAdvice.Header.ForeignTradeIncomingSwiftTransaction.0' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='CommonAdvice.Header.ForeignTradeIncomingSwiftTransaction.0' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','CommonAdvice.Header.ForeignTradeIncomingSwiftTransaction.0','You are not authorized to view this page.','Advice Page',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You are not authorized to view this page.'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='CommonAdvice.Header.ForeignTradeIncomingSwiftTransaction.0' and ChannelId=19 
	end

----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.ForeignTradeIncomingSwiftTransaction' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','HEADER.ForeignTradeIncomingSwiftTransaction','Gelen SWIFT Gözlem','Gelen SWIFT Gözlem',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gelen SWIFT Gözlem'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.ForeignTradeIncomingSwiftTransaction' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.ForeignTradeIncomingSwiftTransaction' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','HEADER.ForeignTradeIncomingSwiftTransaction','Incoming SWIFT Observation','Incoming SWIFT Observation',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Incoming SWIFT Observation'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.ForeignTradeIncomingSwiftTransaction' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.ForeignTradeIncomingSwiftTransaction.start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','HEADER.ForeignTradeIncomingSwiftTransaction.start','Görüntüle & Yönet','Görüntüle & Yönet',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Görüntüle & Yönet'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.ForeignTradeIncomingSwiftTransaction.start' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.ForeignTradeIncomingSwiftTransaction.start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','HEADER.ForeignTradeIncomingSwiftTransaction.start','View & Manage','Görüntüle & Yönet',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='View & Manage'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.ForeignTradeIncomingSwiftTransaction.start' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftGridViewNoRecordsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','IncomingSwiftGridViewNoRecordsText','Aradığınız kriterlere uygun bir transfer işleminiz bulunmamaktadır.','Aradığınız kriterlere uygun bir transfer işleminiz bulunmamaktadır.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Aradığınız kriterlere uygun bir transfer işleminiz bulunmamaktadır.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftGridViewNoRecordsText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftGridViewNoRecordsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','IncomingSwiftGridViewNoRecordsText','You do not have a transfer transaction that meets the criteria you are looking for.','You do not have a transfer transaction that meets the criteria you are looking for.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You do not have a transfer transaction that meets the criteria you are looking for.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftGridViewNoRecordsText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftFinansbankGridViewFilter.HeaderText','Arama','Arama',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Arama'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftFinansbankGridViewFilter.HeaderText','Search','Search',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Search'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.HeaderText' and ChannelId=19 
	end

---------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.StandartViewText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftFinansbankGridViewFilter.StandartViewText','Standart','Standart',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Standart'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.StandartViewText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.StandartViewText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftFinansbankGridViewFilter.StandartViewText','Standard','Standard',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Standard'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.StandartViewText' and ChannelId=19 
	end

---------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.AdvancedViewText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftFinansbankGridViewFilter.AdvancedViewText','Gelişmiş','Gelişmiş',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gelişmiş'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.AdvancedViewText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.AdvancedViewText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftFinansbankGridViewFilter.AdvancedViewText','Advanced','Advanced',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Advanced'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftFinansbankGridViewFilter.AdvancedViewText' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceBasicIncomingSwiftSearchImageButton.ImageText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceBasicIncomingSwiftSearchImageButton.ImageText','Ara','Ara',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ara'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceBasicIncomingSwiftSearchImageButton.ImageText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceBasicIncomingSwiftSearchImageButton.ImageText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceBasicIncomingSwiftSearchImageButton.ImageText','Search','Search',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Search'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceBasicIncomingSwiftSearchImageButton.ImageText' and ChannelId=19 
	end

------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftSearchImageButton.ImageText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceAdvancedIncomingSwiftSearchImageButton.ImageText','Ara','Ara',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ara'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftSearchImageButton.ImageText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftSearchImageButton.ImageText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceAdvancedIncomingSwiftSearchImageButton.ImageText','Search','Search',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Search'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftSearchImageButton.ImageText' and ChannelId=19 
	end


------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceBasicIncomingSwiftTransactionDateLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceBasicIncomingSwiftTransactionDateLabel.Text','İşlem Tarihi','İşlem Tarihi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Tarihi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceBasicIncomingSwiftTransactionDateLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceBasicIncomingSwiftTransactionDateLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceBasicIncomingSwiftTransactionDateLabel.Text','Transaction Date','Transaction Date',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Date'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceBasicIncomingSwiftTransactionDateLabel.Text' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftTransactionDateLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceAdvancedIncomingSwiftTransactionDateLabel.Text','İşlem Tarihi','İşlem Tarihi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Tarihi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftTransactionDateLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftTransactionDateLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceAdvancedIncomingSwiftTransactionDateLabel.Text','Transaction Date','Transaction Date',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Date'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftTransactionDateLabel.Text' and ChannelId=19 
	end

---------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceBasicIncomingSwiftStatusLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceBasicIncomingSwiftStatusLabel.Text','İşlem Durumu','İşlem Durumu',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Durumu'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceBasicIncomingSwiftStatusLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceBasicIncomingSwiftStatusLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceBasicIncomingSwiftStatusLabel.Text','Transaction Status','Transaction Status',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Status'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceBasicIncomingSwiftStatusLabel.Text' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftStatusLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceAdvancedIncomingSwiftStatusLabel.Text','İşlem Durumu','İşlem Durumu',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Durumu'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftStatusLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftStatusLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceAdvancedIncomingSwiftStatusLabel.Text','Transaction Status','Transaction Status',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Status'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftStatusLabel.Text' and ChannelId=19 
	end

------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftStatusLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceAdvancedIncomingSwiftStatusLabel.Text','İşlem Durumu','İşlem Durumu',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Durumu'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftStatusLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftStatusLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceAdvancedIncomingSwiftStatusLabel.Text','Transaction Status','Transaction Status',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Status'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftStatusLabel.Text' and ChannelId=19 
	end

-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftGpiTrackNoLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceAdvancedIncomingSwiftGpiTrackNoLabel.Text','GPI Takip No (UETR)','GPI Takip No (UETR)',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='GPI Takip No (UETR)'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftGpiTrackNoLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftGpiTrackNoLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceAdvancedIncomingSwiftGpiTrackNoLabel.Text','GPI Track Number (UETR)','GPI Track Number (UETR)',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='GPI Track Number (UETR)'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftGpiTrackNoLabel.Text' and ChannelId=19 
	end

--------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftTransferAmountLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceAdvancedIncomingSwiftTransferAmountLabel.Text','Gönderilen Tutar','Gönderilen Tutar',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gönderilen Tutar'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftTransferAmountLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftTransferAmountLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceAdvancedIncomingSwiftTransferAmountLabel.Text','Transferred Amount','Transferred Amount',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transferred Amount'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftTransferAmountLabel.Text' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftDashLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceAdvancedIncomingSwiftDashLabel.Text','-','-',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='-'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftDashLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftDashLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceAdvancedIncomingSwiftDashLabel.Text','-','-',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='-'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftDashLabel.Text' and ChannelId=19 
	end

------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftKeywordLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceAdvancedIncomingSwiftKeywordLabel.Text','Anahtar Kelime','Anahtar Kelime',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Anahtar Kelime'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceAdvancedIncomingSwiftKeywordLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftKeywordLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceAdvancedIncomingSwiftKeywordLabel.Text','Keyword','Keyword',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Keyword'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceAdvancedIncomingSwiftKeywordLabel.Text' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='AdvancedIncomingSwiftKeywordTooltipControl.ToolTip' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','AdvancedIncomingSwiftKeywordTooltipControl.ToolTip','Gönderici unvanı ve alıcı hesap numarası için arama yapılabilir.','',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gönderici unvanı ve alıcı hesap numarası için arama yapılabilir.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='AdvancedIncomingSwiftKeywordTooltipControl.ToolTip' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='AdvancedIncomingSwiftKeywordTooltipControl.ToolTip' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','AdvancedIncomingSwiftKeywordTooltipControl.ToolTip','Search can be made for the sender title and recipient account number.','',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Search can be made for the sender title and recipient account number.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='AdvancedIncomingSwiftKeywordTooltipControl.ToolTip' and ChannelId=19 
	end
------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftTransactionDate.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftTransactionDate.HeaderText','İşlem Tarihi','İşlem Tarihi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Tarihi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftTransactionDate.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftTransactionDate.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftTransactionDate.HeaderText','Transaction Date','Transaction Date',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Date'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftTransactionDate.HeaderText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftValueDate.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftValueDate.HeaderText','Valör Tarihi','Valör Tarihi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Valör Tarihi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftValueDate.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftValueDate.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftValueDate.HeaderText','Value Date','Value Date',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Value Date'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftValueDate.HeaderText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftTransferAmount.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftTransferAmount.HeaderText','Gönderilen Tutar','Gönderilen Tutar',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gönderilen Tutar'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftTransferAmount.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftTransferAmount.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftTransferAmount.HeaderText','Transferred Amount','Transferred Amount',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transferred Amount'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftTransferAmount.HeaderText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftSenderTitle.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftSenderTitle.HeaderText','Gönderici Unvanı','Gönderici Unvanı',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gönderici Unvanı'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftSenderTitle.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftSenderTitle.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftSenderTitle.HeaderText','Sender Title','Sender Title',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Sender Title'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftSenderTitle.HeaderText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftRecipientAccountNo.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftRecipientAccountNo.HeaderText','Alıcı Hesap No','Alıcı Hesap No',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Alıcı Hesap No'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftRecipientAccountNo.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftRecipientAccountNo.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftRecipientAccountNo.HeaderText','Recipient Account Number','Recipient Account Number',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Recipient Account Number'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftRecipientAccountNo.HeaderText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftTransactionStatus.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','ResourceIncomingSwiftTransactionStatus.HeaderText','İşlem Durumu','İşlem Durumu',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Durumu'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='ResourceIncomingSwiftTransactionStatus.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftTransactionStatus.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','ResourceIncomingSwiftTransactionStatus.HeaderText','Transaction Status','Transaction Status',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Status'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='ResourceIncomingSwiftTransactionStatus.HeaderText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftToolTipCurrentTransferAmountText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','IncomingSwiftToolTipCurrentTransferAmountText','Güncel İşlem Tutarı','Güncel İşlem Tutarı',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Güncel İşlem Tutarı'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftToolTipCurrentTransferAmountText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftToolTipCurrentTransferAmountText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','IncomingSwiftToolTipCurrentTransferAmountText','Current Transaction Amount','Current Transaction Amount',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Current Transaction Amount'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftToolTipCurrentTransferAmountText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftToolTipTotalTransactionFeeText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','IncomingSwiftToolTipTotalTransactionFeeText','Toplam İşlem Ücreti','Toplam İşlem Ücreti',NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Toplam İşlem Ücreti'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftToolTipTotalTransactionFeeText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftToolTipTotalTransactionFeeText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','IncomingSwiftToolTipTotalTransactionFeeText','Total Transaction Fee','Total Transaction Fee',NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Total Transaction Fee'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftToolTipTotalTransactionFeeText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='All' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','All','All','',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='All'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='All' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='All' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','All','Hepsi','',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hepsi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='All' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='StartDatePanelNullValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','StartDatePanelNullValidation','Lütfen Başlangıç Tarihini giriniz.','Lütfen Başlangıç Tarihini giriniz.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen Başlangıç Tarihini giriniz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='StartDatePanelNullValidation' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='StartDatePanelNullValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','StartDatePanelNullValidation','Please enter the Start Date.','Please enter the Start Date.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please enter the Start Date.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='StartDatePanelNullValidation' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='StartDatePanelNullValidation2' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','StartDatePanelNullValidation2','Lütfen geçerli bir Başlangıç Tarihi giriniz.','Lütfen geçerli bir Başlangıç Tarihi giriniz.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen geçerli bir Başlangıç Tarihi giriniz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='StartDatePanelNullValidation2' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='StartDatePanelNullValidation2' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','StartDatePanelNullValidation2','Please enter a valid Start Date.','Please enter a valid Start Date.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please enter a valid Start Date.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='StartDatePanelNullValidation2' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='EndDatePanelNullValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','EndDatePanelNullValidation','Lütfen Bitiş Tarihini giriniz.','Lütfen Bitiş Tarihini giriniz.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen Bitiş Tarihini giriniz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='EndDatePanelNullValidation' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='EndDatePanelNullValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','EndDatePanelNullValidation','Please enter the End Date.','Please enter the End Date.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please enter the End Date.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='EndDatePanelNullValidation2' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='EndDatePanelNullValidation2' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','EndDatePanelNullValidation2','Lütfen geçerli bir Bitiş Tarihi giriniz.','Lütfen geçerli bir Bitiş Tarihi giriniz.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen geçerli bir Bitiş Tarihi giriniz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='EndDatePanelNullValidation2' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='EndDatePanelNullValidation2' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','EndDatePanelNullValidation2','Please enter a valid End Date.','Please enter a valid End Date.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please enter a valid End Date.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='EndDatePanelNullValidation2' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='StartDateGreaterEndDateValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','StartDateGreaterEndDateValidation','Başlangıç tarihi bitiş tarihinden büyük olamaz.','Başlangıç tarihi bitiş tarihinden büyük olamaz.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Başlangıç tarihi bitiş tarihinden büyük olamaz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='StartDateGreaterEndDateValidation' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='StartDateGreaterEndDateValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','StartDateGreaterEndDateValidation','Start date can not be greater than end date.','Start date can not be greater than end date.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Start date can not be greater than end date.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='StartDateGreaterEndDateValidation' and ChannelId=19 
	end
-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='BaseValueGreaterCeilValueValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','BaseValueGreaterCeilValueValidation','Tutar aralığı doğru girilmelidir.','Tutar aralığı doğru girilmelidir.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Tutar aralığı doğru girilmelidir.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='BaseValueGreaterCeilValueValidation' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='BaseValueGreaterCeilValueValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','BaseValueGreaterCeilValueValidation','Amount range must be entered correctly.','Amount range must be entered correctly.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Amount range must be entered correctly.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='BaseValueGreaterCeilValueValidation' and ChannelId=19 
	end
-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='BetweenStartDateAndEndDateLimitValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','BetweenStartDateAndEndDateLimitValidation','Başlangıç ve bitiş tarihleri arasında 30 günden fazla olamaz.','Başlangıç ve bitiş tarihleri arasında 30 günden fazla olamaz.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Başlangıç ve bitiş tarihleri arasında 30 günden fazla olamaz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='BetweenStartDateAndEndDateLimitValidation' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='BetweenStartDateAndEndDateLimitValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','BetweenStartDateAndEndDateLimitValidation','There can not be more than 30 days between the start and end dates.','Başlangıç ve bitiş tarihleri arasında 30 günden fazla olamaz.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='There can not be more than 30 days between the start and end dates.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='BetweenStartDateAndEndDateLimitValidation' and ChannelId=19 
	end
-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='NotEnoughLengthForUetrTextValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','NotEnoughLengthForUetrTextValidation','Takip No değeri 36 karakterden oluşmalıdır.','Takip No değeri 36 karakterden oluşmalıdır.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Takip No değeri 36 karakterden oluşmalıdır.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='NotEnoughLengthForUetrTextValidation' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='NotEnoughLengthForUetrTextValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','NotEnoughLengthForUetrTextValidation','Tracking Number value should consist of 36 characters.','Tracking Number value should consist of 36 characters.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Tracking Number value should consist of 36 characters.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='NotEnoughLengthForUetrTextValidation' and ChannelId=19 
	end
-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='TrackNoNullValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','TrackNoNullValidation','Lütfen Takip No değerini giriniz.','Lütfen Takip No değerini giriniz.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen Takip No değerini giriniz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='TrackNoNullValidation' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='TrackNoNullValidation' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','TrackNoNullValidation','Please enter the Tracking No value.','Please enter the Tracking Number value.',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please enter the Tracking Number value.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='TrackNoNullValidation' and ChannelId=19 
	end
-----------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftGridView.PagingNextButtonText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','IncomingSwiftGridView.PagingNextButtonText','Sonraki Kayıtlar','IncomingSwiftGridView.PagingNextButtonText',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Sonraki Kayıtlar'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftGridView.PagingNextButtonText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftGridView.PagingNextButtonText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','IncomingSwiftGridView.PagingNextButtonText','Next Records','IncomingSwiftGridView.PagingNextButtonText',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Next Records'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftGridView.PagingNextButtonText' and ChannelId=19 
	end

----------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftGridView.PagingBackButtonText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','IncomingSwiftGridView.PagingBackButtonText','Önceki Kayıtlar','IncomingSwiftGridView.PagingBackButtonText',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Önceki Kayıtlar'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='IncomingSwiftGridView.PagingBackButtonText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftGridView.PagingBackButtonText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','IncomingSwiftGridView.PagingBackButtonText','Previous Records','IncomingSwiftGridView.PagingBackButtonText',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Previous Records'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='IncomingSwiftGridView.PagingBackButtonText' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='VDADateAndTrackingNoMissingValidationMessageText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','VDADateAndTrackingNoMissingValidationMessageText','Lütfen İşlem Tarihi veya Takip No alanlarına giriş yapınız.','Lütfen İşlem Tarihi veya Takip No alanlarına giriş yapınız.',NULL,'',1,'Mar 21 2021  2:54PM',NULL,NULL,'T64513','Mar 21 2021  2:54PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen İşlem Tarihi veya Takip No alanlarına giriş yapınız.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='VDADateAndTrackingNoMissingValidationMessageText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='VDADateAndTrackingNoMissingValidationMessageText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','VDADateAndTrackingNoMissingValidationMessageText','Please enter the Transaction Date or Tracking Number fields.','Please enter the Transaction Date or Tracking Number fields.',NULL,'',1,'Mar 21 2021  2:54PM',NULL,NULL,'T64513','Mar 21 2021  2:54PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please enter the Transaction Date or Tracking Number fields.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='VDADateAndTrackingNoMissingValidationMessageText' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='VDANoRecordSelectedMessageText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','VDANoRecordSelectedMessageText','Lütfen bir işlem seçiniz.','Lütfen bir işlem seçiniz.',NULL,'',1,'Mar 21 2021  3:53PM',NULL,NULL,'T64513','Mar 21 2021  3:53PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen bir işlem seçiniz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='VDANoRecordSelectedMessageText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='VDANoRecordSelectedMessageText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','VDANoRecordSelectedMessageText','Please select a transaction.','Please select a transaction.',NULL,'',1,'Mar 21 2021  3:53PM',NULL,NULL,'T64513','Mar 21 2021  3:53PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please select a transaction.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='VDANoRecordSelectedMessageText' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='TransationProcessFollowPopupHeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','tr-TR','TransationProcessFollowPopupHeaderText','İşlem Takibi',NULL,NULL,NULL,1,'Mar 21 2021  4:47PM',NULL,NULL,'T64513','Mar 21 2021  4:47PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Takibi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='tr-TR' and ResourceKey='TransationProcessFollowPopupHeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='TransationProcessFollowPopupHeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx','en-US','TransationProcessFollowPopupHeaderText','Transaction Tracking',NULL,NULL,NULL,1,'Mar 21 2021  4:47PM',NULL,NULL,'T64513','Mar 21 2021  4:47PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Tracking'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/IncomingSwiftObservationPage.aspx' and CultureCode='en-US' and ResourceKey='TransationProcessFollowPopupHeaderText' and ChannelId=19 
	end
----------------------
--Popup Resourceları--
----------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionLocatedBankNameTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TransactionLocatedBankNameTextLabel.Text','İşlemin Bulunduğu Banka:',NULL,NULL,NULL,1,'Mar 22 2021  3:09PM',NULL,NULL,'T64513','Mar 22 2021  3:09PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlemin Bulunduğu Banka:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionLocatedBankNameTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionLocatedBankNameTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TransactionLocatedBankNameTextLabel.Text','Transaction Located Bank Name:',NULL,NULL,NULL,1,'Mar 22 2021  3:09PM',NULL,NULL,'T64513','Mar 22 2021  3:09PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Located Bank Name:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionLocatedBankNameTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionSenderBankNameTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TransactionSenderBankNameTextLabel.Text','İşlemin Başlatıldığı Banka:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlemin Başlatıldığı Banka:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionSenderBankNameTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionSenderBankNameTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TransactionSenderBankNameTextLabel.Text','Transaction Sender Bank Name:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Sender Bank Name:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionSenderBankNameTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TotalTransactionFeeTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TotalTransactionFeeTextLabel.Text','Toplam İşlem Ücreti:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Toplam İşlem Ücreti:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TotalTransactionFeeTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TotalTransactionFeeTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TotalTransactionFeeTextLabel.Text','Total Transaction Fee:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Total Transaction Fee:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TotalTransactionFeeTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionStatusTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TransactionStatusTextLabel.Text','İşlem Durumu:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Durumu:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionStatusTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionStatusTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TransactionStatusTextLabel.Text','Transaction Status:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Status:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionStatusTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='RecipientAccountNoTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','RecipientAccountNoTextLabel.Text','Alıcı Hesap Numarası:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Alıcı Hesap Numarası:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='RecipientAccountNoTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='RecipientAccountNoTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','RecipientAccountNoTextLabel.Text','Recipient Account Number:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Recipient Account Number:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='RecipientAccountNoTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='ActualTransactionAmountTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','ActualTransactionAmountTextLabel.Text','Güncel İşlem Tutarı:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Güncel İşlem Tutarı:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='ActualTransactionAmountTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='ActualTransactionAmountTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','ActualTransactionAmountTextLabel.Text','Current Transaction Amount:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Current Transaction Amount:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='ActualTransactionAmountTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TrackingNoTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TrackingNoTextLabel.Text','Takip No:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Takip No:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TrackingNoTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TrackingNoTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TrackingNoTextLabel.Text','Tracking Number:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Tracking Number:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TrackingNoTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransferDescriptionTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TransferDescriptionTextLabel.Text','Transfer Açıklaması:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transfer Açıklaması:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransferDescriptionTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransferDescriptionTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TransferDescriptionTextLabel.Text','Transfer Description:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transfer Description:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransferDescriptionTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionHistoryTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TransactionHistoryTextLabel.Text','İşlem Tarihçesi',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Tarihçesi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionHistoryTextLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionHistoryTextLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TransactionHistoryTextLabel.Text','Transaction History',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction History'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionHistoryTextLabel.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='SenderBank' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','SenderBank','Gönderen Banka:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gönderen Banka:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='SenderBank' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='SenderBank' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','SenderBank','Sender Bank:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Sender Bank:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='SenderBank' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='ReceiverBank' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','ReceiverBank','Alıcı Banka:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Alıcı Banka:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='ReceiverBank' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='ReceiverBank' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','ReceiverBank','Receiver Bank:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Receiver Bank:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='ReceiverBank' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='IntermediateBank' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','IntermediateBank','Aracı Banka:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Aracı Banka:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='IntermediateBank' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='IntermediateBank' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','IntermediateBank','Intermediate Bank:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Intermediate Bank:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='IntermediateBank' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionHistoryTransactionDateAndTimeRepeaterText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TransactionHistoryTransactionDateAndTimeRepeaterText.Text','İşlem Tarihi Ve Saati:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Tarihi Ve Saati:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionHistoryTransactionDateAndTimeRepeaterText.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionHistoryTransactionDateAndTimeRepeaterText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TransactionHistoryTransactionDateAndTimeRepeaterText.Text','Transaction Date And Time:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Date And Time:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionHistoryTransactionDateAndTimeRepeaterText.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionHistoryTransactionFeeRepeaterText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TransactionHistoryTransactionFeeRepeaterText.Text','İşlem Ücreti:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='İşlem Ücreti:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionHistoryTransactionFeeRepeaterText.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionHistoryTransactionFeeRepeaterText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TransactionHistoryTransactionFeeRepeaterText.Text','Transaction Fee:',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Transaction Fee:'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionHistoryTransactionFeeRepeaterText.Text' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='ReceiverBankCode' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','ReceiverBankCode','FNNBTRIS',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='FNNBTRIS'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='ReceiverBankCode' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='ReceiverBankCode' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','ReceiverBankCode','FNNBTRIS',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='FNNBTRIS'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='ReceiverBankCode' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='Help.ForeignTradeIncomingSwiftTransaction.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','Help.ForeignTradeIncomingSwiftTransaction.Start','- By clicking the "Transaction Tracking" button, you can access the current status information regarding the amounts to be paid to our bank accounts.<br><br>- Total fee information regarding the transactions will be shown when the transaction is completed.<br><br>- You can contact with your branch personnel for transaction information older than 1 year.','',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='- By clicking the "Transaction Tracking" button, you can access the current status information regarding the amounts to be paid to our bank accounts.<br><br>- Total fee information regarding the transactions will be shown when the transaction is completed.<br><br>- You can contact with your branch personnel for transaction information older than 1 year.'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='Help.ForeignTradeIncomingSwiftTransaction.Start' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='Help.ForeignTradeIncomingSwiftTransaction.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','Help.ForeignTradeIncomingSwiftTransaction.Start','- "İşlem Takibi" butonuna tıklayarak bankamız hesaplarına gelecek bedellere ilişkin güncel akıbet bilgilerine ulaşabilirsiniz.<br><br>-	İşlemlere dair toplam ücret bilgisi işlem tamamlanınca sonuçlanmış olacaktır.<br><br>- 1 seneden eski işlem bilgileri için şubeniz ile iletişime geçebilirsiniz.','',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='- "İşlem Takibi" butonuna tıklayarak bankamız hesaplarına gelecek bedellere ilişkin güncel akıbet bilgilerine ulaşabilirsiniz.<br><br>- İşlemlere dair toplam ücret bilgisi işlem tamamlanınca sonuçlanmış olacaktır.<br><br>- 1 seneden eski işlem bilgileri için şubeniz ile iletişime geçebilirsiniz.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='Help.ForeignTradeIncomingSwiftTransaction.Start' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionFeeNotExistsInfo' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','tr-TR','TransactionFeeNotExistsInfo','Banka tarafından bilgi verilmemiştir.',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Banka tarafından bilgi verilmemiştir.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='tr-TR' and ResourceKey='TransactionFeeNotExistsInfo' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionFeeNotExistsInfo' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx','en-US','TransactionFeeNotExistsInfo','No information was provided by the bank.',NULL,NULL,NULL,1,'Mar 22 2021  3:33PM',NULL,NULL,'T64513','Mar 22 2021  3:33PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='No information was provided by the bank.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/IncomingSwiftObservation/TransactionProcessFollowPopup.aspx' and CultureCode='en-US' and ResourceKey='TransactionFeeNotExistsInfo' and ChannelId=19 
	end
----------------