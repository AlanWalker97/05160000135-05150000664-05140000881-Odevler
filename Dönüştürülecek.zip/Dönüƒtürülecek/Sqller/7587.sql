select * from VpStringResource where ResourceKey like '%InterestRateText%'

select * from VpStringResource where ResourceValue='Para transferinin yukarýdaki bilgilerle gerçekleþtirileceðini onaylýyorum.'


select * from VpTransactionConfig where Configuration like '%CreateEFTMessageVirtualMain%'

select * from VpTransactionConfig where Configuration like '%TransferMoneyInBankVirtualMain%'

select * from VpTransactionConfig where Configuration like '%EditVirtualMoneyTransferOrderTransaction%'

select * from VpTransactionConfig where Configuration like '%MoneyTransferOrdersMainTransaction%'

select * from VpTransactionConfig where Configuration like '%ModifyMoneyTransferOrdersManagement%'




select * from VpTransactionTemplateConfig where Name='CreateEFTMessageTemplate'

select * from VpTransactionTemplateConfig where Name='TransferMoneyToFinansbankAccountTemplate'

select * from VpTransactionTemplateConfig where Name='EditMoneyTransferOrderTemplate'






select * from VpTransactionConfirmMessages where TransactionID=755 order by ID

select * from VpTransactionConfirmMessages where TransactionID=689 order by ID


--------------------

update VpTransactionTemplateConfig set Configuration='<?xml version="1.0" encoding="utf-8" ?>  <PageTemplates xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://tempuri.org/VeriBranchMessages.xsd">   <PageTemplate ID="Confirm" HtmlTemplateName="ConfirmPageHTMLTemplate">    <InformationContainer HeaderResourceKey="SourceAccountHeader" HeaderResourceType="Database">     <Row TitleResourceKey="SourceAccountText" DataKey="AccountName" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SourceIBAN" DataFormatMethod="ToIban" DataKey="SourceAccount.IBAN" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SourceCreditCardNumber" DataFormatMethod="ToDecryptedCreditCard" DataKey="SourceCreditCard.CardNo" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SourceBalance" DataFormatMethod = "ToMoneyWithCurrency" DataKey="SourceAccount.Balance.Value,SourceAccount.Balance.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SourceLimit" DataFormatMethod = "ToMoneyWithCurrency" DataKey="SourceCreditCard.CurrentDebt.Value,SourceCreditCard.CurrentDebt.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SourceAvailableBalance" DataFormatMethod = "ToMoneyWithCurrency" DataKey="SourceAccount.AvailableBalance.Value,SourceAccount.AvailableBalance.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SourceAvailableLimit" DataFormatMethod = "ToMoneyWithCurrency" DataKey="SourceCreditCard.CreditCardLimit.AvailableLimit.Value,SourceCreditCard.CreditCardLimit.AvailableLimit.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />    </InformationContainer>    <InformationContainer HeaderResourceKey="ProcessDetailsHeader" HeaderResourceType="Database">     <Row TitleResourceKey="RecipientNameText" DataKey="ReceiverCustomer.Name" Condition="IsKolasPaymentProcess!=true" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientNameText" DataKey="MaskedReceiverCustomerNameSurname" Condition="IsKolasPaymentProcess==true" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="BankNameText" DataKey="BankName" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="EasyAddressText" DataKey="EasyAddressText" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="EFTTypeName_Kolas" DataKey="MaskedDestinationAccountIBAN" Condition="MoneyTransferTypeText==''EftWithIBAN'' and IsKolasPaymentProcess==true" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="EFTTypeName_Iban" DataFormatMethod="ToIban" DataKey="DestinationAccount.IBAN" Condition="MoneyTransferTypeText==''EftWithIBAN'' and IsKolasPaymentProcess!=true" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="EFTTypeName_Account" DataKey="DestinationAccount.PaymentAccountNo" Condition="MoneyTransferTypeText==''EftToAccount''" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="EFTTypeName_Name" DataKey="ReferanceInfo" Condition="MoneyTransferTypeText==''EftToName''" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="EFTTypeName_CreditCard" DataFormatMethod="ToDecryptedCreditCard" DataKey="DestinationCreditCard.CardNo" Condition="MoneyTransferTypeText==''EftToCard''" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="PaymentTypeText" DataKey="PaymentTypeText" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="DescriptionText" DataKey="TransactionStatement" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="TransferDateText" DataKey="UniqueTransactionDate" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="AmountText" DataFormatMethod = "ToMoneyWithCurrency" DataKey="Amount.Value,Amount.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="CommissionAmountText" DataFormatMethod = "ToMoneyWithCurrency" DataKey="ShowingCommissionAmount.Value,ShowingCommissionAmount.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" /><Row TitleResourceKey="InterestRateText" DataKey="InterestRateWithPercent" Condition="IsEFTCompatibleWithInterest==true" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="CampaignWarningText" DataKey="CampaignWarningText" ControlType="Campaign" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Row" />     <Row TitleResourceKey="TotalAmountText" DataFormatMethod = "ToMoneyWithCurrency" DataKey="PaymentAmountText.Value,PaymentAmountText.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />    </InformationContainer>   </PageTemplate>   <PageTemplate ID="Execute" HtmlTemplateName="ExecutePageHTMLTemplate" UseCommonExecutePage="true"></PageTemplate>  </PageTemplates>' where Name='CreateEFTMessageTemplate'

update VpTransactionTemplateConfig set Configuration='<?xml version="1.0" encoding="utf-8" ?>  <PageTemplates xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://tempuri.org/VeriBranchMessages.xsd">   <PageTemplate ID="Confirm" HtmlTemplateName="ConfirmPageHTMLTemplate">    <InformationContainer HeaderResourceKey="SenderAccountHeader" HeaderResourceType="Database">     <Row TitleResourceKey="SenderAccountName" DataKey="SourceAccountName" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SenderIBAN" DataKey="SourceAccount.IBAN" DataFormatMethod="ToIban" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SenderBalance" DataFormatMethod="ToMoneyWithCurrency" DataKey="SourceAccount.Balance.Value,SourceAccount.Balance.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SenderAvailableBalance" DataFormatMethod="ToMoneyWithCurrency" DataKey="SourceAccount.AvailableBalance.Value,SourceAccount.AvailableBalance.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SenderCreditCardName" DataKey="SourceCreditCard.ProductName" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="CreditCardNumber" DataFormatMethod="ToDecryptedCreditCard" DataKey="SourceCreditCard.CardNo" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="CurrentDebt" DataFormatMethod="ToMoneyWithCurrency" DataKey="SourceCreditCard.CurrentDebt.Value,SourceCreditCard.CurrentDebt.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="SenderAvailableLimit" DataFormatMethod="ToMoneyWithCurrency" DataKey="SourceCreditCard.CreditCardLimit.AvailableLimit.Value,SourceCreditCard.CreditCardLimit.AvailableLimit.Currency.Name" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />    </InformationContainer>    <InformationContainer HeaderResourceKey="ReceiverAccountHeader" HeaderResourceType="Database">     <Row TitleResourceKey="RecipientName" DataKey="ReceiverCustomer.Name" Condition="TransferSendingTypeForConfirmationPage==''ToIBAN'' and (ReceipentNameIsMasked==0 or ReceipentNameIsMasked==null)" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientName" DataKey="ReceiverNameMask" Condition="TransferSendingTypeForConfirmationPage==''ToIBAN'' and ReceipentNameIsMasked==1" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientName" DataKey="ReceiverCustomer.Name" Condition="TransferSendingTypeForConfirmationPage==''ToAccountNumber'' and (ReceipentNameIsMasked==0 or ReceipentNameIsMasked==null)" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientName" DataKey="ReceiverNameMask" Condition="TransferSendingTypeForConfirmationPage==''ToAccountNumber'' and ReceipentNameIsMasked==1" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientName" DataKey="ReceiverCustomer.Name" Condition="TransferSendingTypeForConfirmationPage==''ToCreditCard''" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientName" DataKey="ReceiverCustomer.Name,ReceiverCustomer.Surname" Condition="TransferSendingTypeForConfirmationPage==''ToName''" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientTCKN" DataKey="ReceiverCustomer.TCID" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientYKN" DataKey="ReceiverCustomer.ForeignPidNo" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="RecipientVKN" DataKey="VKN" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="FastRecordName" DataKey="FastRecordName" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="EasyAddressText" DataKey="EasyAddressText" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="ToIBANKolas" DataKey="MaskedDestinationAccountIBAN" Condition="TransferSendingTypeForConfirmationPage==''ToIBAN'' and IsKolasPaymentProcess==true" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="ToIBAN" DataKey="DestinationAccount.IBAN" DataFormatMethod="ToIban" Condition="TransferSendingTypeForConfirmationPage==''ToIBAN'' and IsKolasPaymentProcess!=true" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="ToAccountNumber" DataKey="DestinationAccount.AccNumber" Condition="TransferSendingTypeForConfirmationPage==''ToAccountNumber''" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="ToName" DataKey="ReceiverInfoForConfirmationPage" Condition="TransferSendingTypeForConfirmationPage==''ToName''" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="ToCreditCard" DataKey="ReceiverCreditCardNumberForConfirmationPage" Condition="TransferSendingTypeForConfirmationPage==''ToCreditCard''" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="PaymentType" DataKey="PaymentTypeText" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="Description" DataKey="Description" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="TransferDate" DataFormatMethod="ToShortDate" DataKey="TransferDate" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="TransferAmount" DataFormatMethod="ToMoneyWithCurrency" DataKey="Amount.Value,SourceAccount.Balance.Currency.Name" Condition="SourceAccount!=null" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="TransferAmount" DataFormatMethod="ToMoneyWithCurrency" DataKey="Amount.Value,SourceCreditCard.CreditCardLimit.AvailableLimit.Currency.Name" Condition="SourceCreditCard!=null" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="CommissionFee" DataFormatMethod="ToMoneyWithCurrency" DataKey="CommissionFee,SourceAccount.Balance.Currency.Name" Condition="SourceAccount!=null" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="CommissionFee" DataFormatMethod="ToMoneyWithCurrency" DataKey="CommissionFee,SourceCreditCard.CreditCardLimit.AvailableLimit.Currency.Name" Condition="SourceCreditCard!=null" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="InterestRateText" DataKey="InterestRateWithPercent" Condition="IsMoneyTransferCompatibleWithInterest==true" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="CampaignWarningText" DataKey="CampaignWarningText" ControlType="Campaign" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Row" />     <Row TitleResourceKey="TotalAmount" DataFormatMethod="ToMoneyWithCurrency" DataKey="TotalAmount,SourceAccount.Balance.Currency.Name" Condition="SourceAccount!=null" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="TotalAmount" DataFormatMethod="ToMoneyWithCurrency" DataKey="TotalAmount,SourceCreditCard.CreditCardLimit.AvailableLimit.Currency.Name" Condition="SourceCreditCard!=null" ConditionSource="StateBag" TitleResourceType="Database" InformationItemType="Big" />     <Row TitleResourceKey="GetForTransferNameComisionText" DataKey="GetForTransferNameComision" TitleResourceType="Database" InformationItemType="Big" />    </InformationContainer>   </PageTemplate>   <PageTemplate ID="Execute" HtmlTemplateName="ExecutePageHTMLTemplate" UseCommonExecutePage="true"></PageTemplate>  </PageTemplates>' where Name='TransferMoneyToFinansbankAccountTemplate'

if not exists(select 1 from VpTransactionConfirmMessages where Condition='IsEFTCompatibleWithInterest == true' and CultureCode='tr-TR' and ChannelID=2) begin insert into VpTransactionConfirmMessages(TransactionID,CultureCode,Message,StateKey,PagePath,CustomerType,ChannelID,MessageType,Condition,MessageOrder,ModifyBy,ModifyDate,CreateBy,CreateDate) values (755,'tr-TR','','InterestRateMessage','default.aspx',1,2,1,'IsEFTCompatibleWithInterest == true',4,'T64513',getdate(),'T64513',getdate()) end

if not exists(select 1 from VpTransactionConfirmMessages where Condition='IsEFTCompatibleWithInterest == true' and CultureCode='tr-TR' and ChannelID=19) begin insert into VpTransactionConfirmMessages(TransactionID,CultureCode,Message,StateKey,PagePath,CustomerType,ChannelID,MessageType,Condition,MessageOrder,ModifyBy,ModifyDate,CreateBy,CreateDate) values (755,'tr-TR','','InterestRateMessage','default.aspx',1,19,1,'IsEFTCompatibleWithInterest == true',4,'T64513',getdate(),'T64513',getdate()) end

if not exists(select 1 from VpTransactionConfirmMessages where Condition='IsEFTCompatibleWithInterest == true' and CultureCode='en-US' and ChannelID=2) begin insert into VpTransactionConfirmMessages(TransactionID,CultureCode,Message,StateKey,PagePath,CustomerType,ChannelID,MessageType,Condition,MessageOrder,ModifyBy,ModifyDate,CreateBy,CreateDate) values (755,'en-US','','InterestRateMessage','default.aspx',1,2,1,'IsEFTCompatibleWithInterest == true',4,'T64513',getdate(),'T64513',getdate()) end

if not exists(select 1 from VpTransactionConfirmMessages where Condition='IsEFTCompatibleWithInterest == true' and CultureCode='en-US' and ChannelID=19) begin insert into VpTransactionConfirmMessages(TransactionID,CultureCode,Message,StateKey,PagePath,CustomerType,ChannelID,MessageType,Condition,MessageOrder,ModifyBy,ModifyDate,CreateBy,CreateDate) values (755,'en-US','','InterestRateMessage','default.aspx',1,19,1,'IsEFTCompatibleWithInterest == true',4,'T64513',getdate(),'T64513',getdate()) end

update VpTransactionConfirmMessages set MessageOrder=1 where TransactionID=689

if not exists(select 1 from VpTransactionConfirmMessages where Condition='IsMoneyTransferCompatibleWithInterest == true' and CultureCode='tr-TR' and ChannelID=2) begin insert into VpTransactionConfirmMessages(TransactionID,CultureCode,Message,StateKey,PagePath,CustomerType,ChannelID,MessageType,Condition,MessageOrder,ModifyBy,ModifyDate,CreateBy,CreateDate) values (689,'tr-TR','','InterestRateMessage','default.aspx',1,2,1,'IsMoneyTransferCompatibleWithInterest == true',2,'T64513',getdate(),'T64513',getdate()) end

if not exists(select 1 from VpTransactionConfirmMessages where Condition='IsMoneyTransferCompatibleWithInterest == true' and CultureCode='tr-TR' and ChannelID=19) begin insert into VpTransactionConfirmMessages(TransactionID,CultureCode,Message,StateKey,PagePath,CustomerType,ChannelID,MessageType,Condition,MessageOrder,ModifyBy,ModifyDate,CreateBy,CreateDate) values (689,'tr-TR','','InterestRateMessage','default.aspx',1,19,1,'IsMoneyTransferCompatibleWithInterest == true',2,'T64513',getdate(),'T64513',getdate()) end

if not exists(select 1 from VpTransactionConfirmMessages where Condition='IsMoneyTransferCompatibleWithInterest == true' and CultureCode='en-US' and ChannelID=2) begin insert into VpTransactionConfirmMessages(TransactionID,CultureCode,Message,StateKey,PagePath,CustomerType,ChannelID,MessageType,Condition,MessageOrder,ModifyBy,ModifyDate,CreateBy,CreateDate) values (689,'en-US','','InterestRateMessage','default.aspx',1,2,1,'IsMoneyTransferCompatibleWithInterest == true',2,'T64513',getdate(),'T64513',getdate()) end

if not exists(select 1 from VpTransactionConfirmMessages where Condition='IsMoneyTransferCompatibleWithInterest == true' and CultureCode='en-US' and ChannelID=19) begin insert into VpTransactionConfirmMessages(TransactionID,CultureCode,Message,StateKey,PagePath,CustomerType,ChannelID,MessageType,Condition,MessageOrder,ModifyBy,ModifyDate,CreateBy,CreateDate) values (689,'en-US','','InterestRateMessage','default.aspx',1,19,1,'IsMoneyTransferCompatibleWithInterest == true',2,'T64513',getdate(),'T64513',getdate()) end

------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='CreateEFTMessage.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('CreateEFTMessage.CONFIRM','tr-TR','InterestRateText','Faiz Oranı','Faiz Oranı',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Faiz Oranı', FriendlyName='Faiz Oranı'
			where ResourceType='CreateEFTMessage.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=2 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='CreateEFTMessage.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('CreateEFTMessage.CONFIRM','en-US','InterestRateText','Interest Rate','Interest Rate',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Interest Rate', FriendlyName='Interest Rate'
			where ResourceType='CreateEFTMessage.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=2 
	end

-------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='CreateEFTMessage.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('CreateEFTMessage.CONFIRM','tr-TR','InterestRateText','Faiz Oraný','Faiz Oraný',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Faiz Oraný', FriendlyName='Faiz Oraný'
			where ResourceType='CreateEFTMessage.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='CreateEFTMessage.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('CreateEFTMessage.CONFIRM','en-US','InterestRateText','Interest Rate','Interest Rate',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Interest Rate', FriendlyName='Interest Rate'
			where ResourceType='CreateEFTMessage.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=19
	end
--------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='CreateEFTMessageVirtualMain.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('CreateEFTMessageVirtualMain.CONFIRM','tr-TR','InterestRateText','Faiz Oraný','Faiz Oraný',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Faiz Oranı', FriendlyName='Faiz Oraný'
			where ResourceType='CreateEFTMessageVirtualMain.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=2 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='CreateEFTMessageVirtualMain.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('CreateEFTMessageVirtualMain.CONFIRM','en-US','InterestRateText','Interest Rate','Interest Rate',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Interest Rate', FriendlyName='Interest Rate'
			where ResourceType='CreateEFTMessageVirtualMain.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=2 
	end

-------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='CreateEFTMessageVirtualMain.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('CreateEFTMessageVirtualMain.CONFIRM','tr-TR','InterestRateText','Faiz Oraný','Faiz Oraný',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Faiz Oraný', FriendlyName='Faiz Oraný'
			where ResourceType='CreateEFTMessageVirtualMain.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='CreateEFTMessageVirtualMain.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('CreateEFTMessageVirtualMain.CONFIRM','en-US','InterestRateText','Interest Rate','Interest Rate',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Interest Rate', FriendlyName='Interest Rate'
			where ResourceType='CreateEFTMessageVirtualMain.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=19
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx' and CultureCode='tr-TR' and ResourceKey='InterestRateMessage' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx','tr-TR','InterestRateMessage','Kredi kartýnýzdan yapacaðýnýz EFT iþlemi nakit çekim olarak deðerlendirildiðinden iþlem tutarýnýza yürürlükte olan {0} oranýnda aylýk azami akdi faiz yansýtýlacaktýr.Akdi faiz oranýnda deðiþiklik olmasý halinde güncel oran uygulanacaktýr.','Faiz Oraný Mesajý',NULL,'',1,'May 12 2021  1:57PM',NULL,NULL,'T64513','May 12 2021  1:57PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kredi kartýnýzdan yapacaðýnýz EFT iþlemi nakit çekim olarak deðerlendirildiðinden iþlem tutarýnýza yürürlükte olan {0} oranýnda aylýk azami akdi faiz yansýtýlacaktýr.Akdi faiz oranýnda deðiþiklik olmasý halinde güncel oran uygulanacaktýr.', FriendlyName='Faiz Oraný Mesajý'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx' and CultureCode='tr-TR' and ResourceKey='InterestRateMessage' and ChannelId=2 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx' and CultureCode='en-US' and ResourceKey='InterestRateMessage' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx','en-US','InterestRateMessage','Monthly maximum contractual interest of {0}% in effect shall be charged to the transaction amount since the EFT transaction from your credit card is considered as a cash withdrawal transaction. If the contractual interest rate changes, the up-to-date rate shall apply.','Interest Rate Message',NULL,'',1,'May 12 2021  1:57PM',NULL,NULL,'T64513','May 12 2021  1:57PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Monthly maximum contractual interest of {0}% in effect shall be charged to the transaction amount since the EFT transaction from your credit card is considered as a cash withdrawal transaction. If the contractual interest rate changes, the up-to-date rate shall apply.', FriendlyName='Interest Rate Message'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx' and CultureCode='en-US' and ResourceKey='InterestRateMessage' and ChannelId=2 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx' and CultureCode='tr-TR' and ResourceKey='InterestRateMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx','tr-TR','InterestRateMessage','Kredi kartýnýzdan yapacaðýnýz EFT iþlemi nakit çekim olarak deðerlendirildiðinden iþlem tutarýnýza yürürlükte olan {0} oranýnda aylýk azami akdi faiz yansýtýlacaktýr.Akdi faiz oranýnda deðiþiklik olmasý halinde güncel oran uygulanacaktýr.','Faiz Oraný Mesajý',NULL,'',1,'May 12 2021  1:57PM',NULL,NULL,'T64513','May 12 2021  1:57PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kredi kartýnýzdan yapacaðýnýz EFT iþlemi nakit çekim olarak deðerlendirildiðinden iþlem tutarýnýza yürürlükte olan {0} oranýnda aylýk azami akdi faiz yansýtýlacaktýr.Akdi faiz oranýnda deðiþiklik olmasý halinde güncel oran uygulanacaktýr.', FriendlyName='Faiz Oraný Mesajý'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx' and CultureCode='tr-TR' and ResourceKey='InterestRateMessage' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx' and CultureCode='en-US' and ResourceKey='InterestRateMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx','en-US','InterestRateMessage','Monthly maximum contractual interest of {0}% in effect shall be charged to the transaction amount since the EFT transaction from your credit card is considered as a cash withdrawal transaction. If the contractual interest rate changes, the up-to-date rate shall apply.','Interest Rate Message',NULL,'',1,'May 12 2021  1:57PM',NULL,NULL,'T64513','May 12 2021  1:57PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Monthly maximum contractual interest of {0}% in effect shall be charged to the transaction amount since the EFT transaction from your credit card is considered as a cash withdrawal transaction. If the contractual interest rate changes, the up-to-date rate shall apply.', FriendlyName='Interest Rate Message'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToOtherBankAccount/EFT/TransferDetails.aspx' and CultureCode='en-US' and ResourceKey='InterestRateMessage' and ChannelId=19 
	end
------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='TransferMoneyInBankVirtualMain.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('TransferMoneyInBankVirtualMain.CONFIRM','tr-TR','InterestRateText','Faiz Oraný','Faiz Oraný',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Faiz Oraný', FriendlyName='Faiz Oraný'
			where ResourceType='TransferMoneyInBankVirtualMain.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=2 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='TransferMoneyInBankVirtualMain.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('TransferMoneyInBankVirtualMain.CONFIRM','en-US','InterestRateText','Interest Rate','Interest Rate',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Interest Rate', FriendlyName='Interest Rate'
			where ResourceType='TransferMoneyInBankVirtualMain.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=2 
	end

-------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='TransferMoneyInBankVirtualMain.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('TransferMoneyInBankVirtualMain.CONFIRM','tr-TR','InterestRateText','Faiz Oraný','Faiz Oraný',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Faiz Oraný', FriendlyName='Faiz Oraný'
			where ResourceType='TransferMoneyInBankVirtualMain.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InterestRateText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='TransferMoneyInBankVirtualMain.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('TransferMoneyInBankVirtualMain.CONFIRM','en-US','InterestRateText','Interest Rate','Interest Rate',NULL,'',1,'May 12 2021 12:18PM',NULL,NULL,'T64513','May 12 2021 12:18PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Interest Rate', FriendlyName='Interest Rate'
			where ResourceType='TransferMoneyInBankVirtualMain.CONFIRM' and CultureCode='en-US' and ResourceKey='InterestRateText' and ChannelId=19
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx' and CultureCode='tr-TR' and ResourceKey='InterestRateMessage' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx','tr-TR','InterestRateMessage','Kredi kartýnýzdan yapacaðýnýz Havale iþlemi nakit çekim olarak deðerlendirildiðinden iþlem tutarýnýza yürürlükte olan {0} oranýnda aylýk azami akdi faiz yansýtýlacaktýr.Akdi faiz oranýnda deðiþiklik olmasý halinde güncel oran uygulanacaktýr.','Faiz Oraný Mesajý',NULL,'',1,'May 12 2021  1:57PM',NULL,NULL,'T64513','May 12 2021  1:57PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kredi kartýnýzdan yapacaðýnýz Havale iþlemi nakit çekim olarak deðerlendirildiðinden iþlem tutarýnýza yürürlükte olan {0} oranýnda aylýk azami akdi faiz yansýtýlacaktýr.Akdi faiz oranýnda deðiþiklik olmasý halinde güncel oran uygulanacaktýr.', FriendlyName='Faiz Oraný Mesajý'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx' and CultureCode='tr-TR' and ResourceKey='InterestRateMessage' and ChannelId=2 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx' and CultureCode='en-US' and ResourceKey='InterestRateMessage' and ChannelId=2) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx','en-US','InterestRateMessage','Monthly maximum contractual interest of {0}% in effect shall be charged to the transaction amount since the Money Transfer transaction from your credit card is considered as a cash withdrawal transaction. If the contractual interest rate changes, the up-to-date rate shall apply.','Interest Rate Message',NULL,'',1,'May 12 2021  1:57PM',NULL,NULL,'T64513','May 12 2021  1:57PM',NULL,'0',NULL,'2') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Monthly maximum contractual interest of {0}% in effect shall be charged to the transaction amount since the Money Transfer transaction from your credit card is considered as a cash withdrawal transaction. If the contractual interest rate changes, the up-to-date rate shall apply.', FriendlyName='Interest Rate Message'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx' and CultureCode='en-US' and ResourceKey='InterestRateMessage' and ChannelId=2 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx' and CultureCode='tr-TR' and ResourceKey='InterestRateMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx','tr-TR','InterestRateMessage','Kredi kartýnýzdan yapacaðýnýz Havale iþlemi nakit çekim olarak deðerlendirildiðinden iþlem tutarýnýza yürürlükte olan {0} oranýnda aylýk azami akdi faiz yansýtýlacaktýr.Akdi faiz oranýnda deðiþiklik olmasý halinde güncel oran uygulanacaktýr.','Faiz Oraný Mesajý',NULL,'',1,'May 12 2021  1:57PM',NULL,NULL,'T64513','May 12 2021  1:57PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kredi kartýnýzdan yapacaðýnýz Havale iþlemi nakit çekim olarak deðerlendirildiðinden iþlem tutarýnýza yürürlükte olan {0} oranýnda aylýk azami akdi faiz yansýtýlacaktýr.Akdi faiz oranýnda deðiþiklik olmasý halinde güncel oran uygulanacaktýr.', FriendlyName='Faiz Oraný Mesajý'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx' and CultureCode='tr-TR' and ResourceKey='InterestRateMessage' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx' and CultureCode='en-US' and ResourceKey='InterestRateMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx','en-US','InterestRateMessage','Monthly maximum contractual interest of {0}% in effect shall be charged to the transaction amount since the Money Transfer transaction from your credit card is considered as a cash withdrawal transaction. If the contractual interest rate changes, the up-to-date rate shall apply.','Interest Rate Message',NULL,'',1,'May 12 2021  1:57PM',NULL,NULL,'T64513','May 12 2021  1:57PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Monthly maximum contractual interest of {0}% in effect shall be charged to the transaction amount since the Money Transfer transaction from your credit card is considered as a cash withdrawal transaction. If the contractual interest rate changes, the up-to-date rate shall apply.', FriendlyName='Interest Rate Message'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/ToFinansbankAccount/Transfer.aspx' and CultureCode='en-US' and ResourceKey='InterestRateMessage' and ChannelId=19 
	end
------------------