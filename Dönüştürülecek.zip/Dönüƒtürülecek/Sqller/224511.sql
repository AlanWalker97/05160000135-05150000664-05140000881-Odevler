update VpStringResource set ResourceValue='Remaining Form Balance' , FriendlyName='Remaining Form Balance' where ResourceKey='DeclarationFormBalanceBoundColumn.HeaderText' and ResourceType='WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx' and CultureCode='en-US'

update VpStringResource set ResourceValue='Kalan Beyanname Bakiyesi' , FriendlyName='Kalan Beyanname Bakiyesi' where ResourceKey='DeclarationFormBalanceBoundColumn.HeaderText' and ResourceType='WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx' and CultureCode='tr-TR'

update VpStringResource set ResourceValue='Country Name:', FriendlyName='Country Name:' where ResourceKey like 'CountryBoundColumn.HeaderText' and ResourceType='WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx' and CultureCode='en-US'

update VpStringResource set ResourceValue='Ülke Adı:', FriendlyName='Ülke Adı:' where ResourceKey like 'CountryBoundColumn.HeaderText' and ResourceType='WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx' and CultureCode='tr-TR'
------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx' and CultureCode='tr-TR' and ResourceKey='CurrencyLastBringDateBoundColumn.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx','tr-TR','CurrencyLastBringDateBoundColumn.HeaderText','Döviz Getirme Son Tarihi','Döviz Getirme Son Tarihi',NULL,NULL,1,'Apr 20 2021  4:02PM',NULL,NULL,'T64513','Apr 20 2021  4:02PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Döviz Getirme Son Tarihi', FriendlyName='Döviz Getirme Son Tarihi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx' and CultureCode='tr-TR' and ResourceKey='CurrencyLastBringDateBoundColumn.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx' and CultureCode='en-US' and ResourceKey='CurrencyLastBringDateBoundColumn.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx','en-US','CurrencyLastBringDateBoundColumn.HeaderText','Foreign Currency Conversion Deadline','Foreign Currency Conversion Deadline',NULL,NULL,1,'Apr 20 2021  4:02PM',NULL,NULL,'T64513','Apr 20 2021  4:02PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Foreign Currency Conversion Deadline', FriendlyName='Foreign Currency Conversion Deadline'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/GeneralPopups/CustomsDeclarationFormSelection.aspx' and CultureCode='en-US' and ResourceKey='CurrencyLastBringDateBoundColumn.HeaderText' and ChannelId=19 
	end

------------------


