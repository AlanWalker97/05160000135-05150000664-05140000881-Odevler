if not Exists(select 1 from vpStringResource(nolock) where ResourceType='ForeignTradeInvisibleNewOperation.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InvisiblePen' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('ForeignTradeInvisibleNewOperation.CONFIRM','tr-TR','InvisiblePen','GORUNMEYENKALEM','GORUNMEYENKALEM',NULL,NULL,1,'Apr  9 2015  2:14PM',NULL,NULL,'ABERCIN','Jan 12 2015  9:05AM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='GORUNMEYENKALEM'
			where ResourceType='ForeignTradeInvisibleNewOperation.CONFIRM' and CultureCode='tr-TR' and ResourceKey='InvisiblePen' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='ForeignTradeInvisibleNewOperation.CONFIRM' and CultureCode='en-US' and ResourceKey='InvisiblePen' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('ForeignTradeInvisibleNewOperation.CONFIRM','en-US','InvisiblePen','GORUNMEYENKALEM','GORUNMEYENKALEM',NULL,NULL,1,'Apr  9 2015  2:14PM',NULL,NULL,'ABERCIN','Jan 12 2015  9:05AM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='GORUNMEYENKALEM'
			where ResourceType='ForeignTradeInvisibleNewOperation.CONFIRM' and CultureCode='en-US' and ResourceKey='InvisiblePen' and ChannelId=19 
	end

update VpStringResource set ResourceType='GeneralResource' where ResourceKey='InvisiblePen'