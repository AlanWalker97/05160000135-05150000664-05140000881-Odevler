if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='PaidCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','tr-TR','PaidCheque','�denmi� �ek','�denmi� �ek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�denmi� �ek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='PaidCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='PaidCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','en-US','PaidCheque','�denmi� �ek','�denmi� �ek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�denmi� �ek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='PaidCheque' and ChannelId=19 
	end

------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='BouncedCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','tr-TR','BouncedCheque','Kar��l�ks�z �ek','Kar��l�ks�z �ek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kar��l�ks�z �ek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='BouncedCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='BouncedCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','en-US','BouncedCheque','Kar��l�ks�z �ek','Kar��l�ks�z �ek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kar��l�ks�z �ek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='BouncedCheque' and ChannelId=19 
	end

--------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='MistakenCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','tr-TR','MistakenCheque','Hatal� �ek','Hatal� �ek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hatal� �ek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='MistakenCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='MistakenCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','en-US','MistakenCheque','Hatal� �ek','Hatal� �ek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hatal� �ek'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='MistakenCheque' and ChannelId=19 
	end

----------------------------



if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='CourtBannedCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','tr-TR','CourtBannedCheque','Mahkeme �deme Yasakl�','Mahkeme �deme Yasakl�',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Mahkeme �deme Yasakl�'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='tr-TR' and ResourceKey='CourtBannedCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='CourtBannedCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx','en-US','CourtBannedCheque','Mahkeme �deme Yasakl�','Mahkeme �deme Yasakl�',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Mahkeme �deme Yasakl�'
			where ResourceType='WebApplication.UI/Transactions/Accounts/Bonds/ChecksReceivable.aspx' and CultureCode='en-US' and ResourceKey='CourtBannedCheque' and ChannelId=19 
	end

----------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='MistakenCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','MistakenCheque','Hatal� �ek','Hatal� �ek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hatal� �ek'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='MistakenCheque' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='MistakenCheque' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','MistakenCheque','Hatal� �ek','Hatal� �ek',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Hatal� �ek'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='MistakenCheque' and ChannelId=19 
	end

----------------------------