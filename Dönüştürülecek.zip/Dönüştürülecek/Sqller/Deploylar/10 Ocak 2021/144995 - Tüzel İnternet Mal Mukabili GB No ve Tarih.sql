if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DeclarationDateAndNumberLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','DeclarationDateAndNumberLabel.Text','Beyanname Tarihi/No','DeclarationDateAndNumberLabel.Text',NULL,NULL,1,'Dec  16 2020  1:50PM',NULL,NULL,'T64513','Dec  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Beyanname Tarihi/No'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DeclarationDateAndNumberLabel.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DeclarationDateAndNumberLabel.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','DeclarationDateAndNumberLabel.Text','Declaration Date/Number','DeclarationDateAndNumberLabel.Text',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Declaration Date/Number'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DeclarationDateAndNumberLabel.Text' and ChannelId=19 
	end

-----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DeclarationDateTooltipControl.ToolTip' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','DeclarationDateTooltipControl.ToolTip','L�tfen 16 haneli beyanname numaras�n�n son 6 hanesini giriniz.','',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='L�tfen 16 haneli beyanname numaras�n�n son 6 hanesini giriniz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DeclarationDateTooltipControl.ToolTip' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DeclarationDateTooltipControl.ToolTip' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','DeclarationDateTooltipControl.ToolTip','Please enter the last 6 digits of the 16-digit declaration number.','',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please enter the last 6 digits of the 16-digit declaration number.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DeclarationDateTooltipControl.ToolTip' and ChannelId=19 
	end

-----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DocumentTooltipControl.ToolTip' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','DocumentTooltipControl.ToolTip','Dok�man Y�klemek Zorunlu De�ildir. Bankam�z taraf�ndan talep edilmesi halinde bu alan� kullanman�z� rica ederiz.','',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Dok�man Y�klemek Zorunlu De�ildir. Bankam�z taraf�ndan talep edilmesi halinde bu alan� kullanman�z� rica ederiz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DocumentTooltipControl.ToolTip' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DocumentTooltipControl.ToolTip' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','DocumentTooltipControl.ToolTip','It Is Not Required To Upload Documents. If requested by our bank, we ask you to use this area.','',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='It Is Not Required To Upload Documents. If requested by our bank, we ask you to use this area.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DocumentTooltipControl.ToolTip' and ChannelId=19 
	end

-----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='PleaseAddDeclarationDateAndNumberText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','PleaseAddDeclarationDateAndNumberText','Mal mukabili �deme �ekli i�in en az 1 tane g�mr�k beyannamesi Numaras� ve Tarihinin girilmesi zorunludur.','PleaseAddDeclarationDateAndNumberText',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Mal mukabili �deme �ekli i�in en az 1 tane g�mr�k beyannamesi Numaras� ve Tarihinin girilmesi zorunludur.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='PleaseAddDeclarationDateAndNumberText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='PleaseAddDeclarationDateAndNumberText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','PleaseAddDeclarationDateAndNumberText','At least 1 customs declaration Number and Date must be entered for the payment method against goods.','PleaseAddDeclarationDateAndNumberText',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='At least 1 customs declaration Number and Date must be entered for the payment method against goods.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='PleaseAddDeclarationDateAndNumberText' and ChannelId=19 
	end

------------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DeclarationDateAndNumberMustTogetherInformationText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','DeclarationDateAndNumberMustTogetherInformationText','Beyanname Tarihi ve Numaras� alanlar� eklenece�i zaman her iki alan da doldurulmal�d�r.','Beyanname Tarihi ve Numaras� alanlar� eklenece�i zaman her iki alan da doldurulmal�d�r.',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Beyanname Tarihi ve Numaras� alanlar� eklenece�i zaman her iki alan da doldurulmal�d�r.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DeclarationDateAndNumberMustTogetherInformationText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DeclarationDateAndNumberMustTogetherInformationText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','DeclarationDateAndNumberMustTogetherInformationText','When adding the Declaration Date and Number fields, both fields must be filled.','When adding the Declaration Date and Number fields, both fields must be filled.',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='When adding the Declaration Date and Number fields, both fields must be filled.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DeclarationDateAndNumberMustTogetherInformationText' and ChannelId=19 
	end

-----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DeclarationNumberLengthInformationText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','DeclarationNumberLengthInformationText','Beyanname Numaras�n� 6 basamak olacak �ekilde giriniz.','Beyanname Numaras�n� 6 basamak olacak �ekilde giriniz.',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Beyanname Numaras�n� 6 basamak olacak �ekilde giriniz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='DeclarationNumberLengthInformationText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DeclarationNumberLengthInformationText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','DeclarationNumberLengthInformationText','Enter the Declaration Number in 6 digits.','Enter the Declaration Number in 6 digits.',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Enter the Declaration Number in 6 digits.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='DeclarationNumberLengthInformationText' and ChannelId=19 
	end

----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='MaximumFileSelectionCount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','MaximumFileSelectionCount','10','Max Y�klenecek Dosya Say�s�',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='10'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='MaximumFileSelectionCount' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='MaximumFileSelectionCount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','MaximumFileSelectionCount','10','Max Number of Files to Upload',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='10'
			where ResourceType='WebApplication.UI/T�m alanlar bo� iken ekleme yap�lamaz.Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='MaximumFileSelectionCount' and ChannelId=19 
	end

----------------------
update VpStringResource set ResourceValue='Maksimum {0} adet dosya girebilirsiniz.' , FriendlyName='Maksimum {0} adet dosya girebilirsiniz.' , LastAccessTime='Nov  16 2020  1:50PM' , ModifyDate='Nov  16 2020  1:50PM' , ModifyBy='T64513' where ResourceKey='MaximumSelectionCountText' and CultureCode='tr-TR' and ChannelId=19 

update VpStringResource set ResourceValue='You can upload up to {0} files.' , FriendlyName='You can upload up to {0} files.' , LastAccessTime='Nov  16 2020  1:50PM' , ModifyDate='Nov  16 2020  1:50PM' , ModifyBy='T64513' where ResourceKey='MaximumSelectionCountText' and CultureCode='en-US' and ChannelId=19 

----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='AllFieldsCannotBeEmptyInformationText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','AllFieldsCannotBeEmptyInformationText','T�m alanlar bo� iken ekleme yap�lamaz.','T�m alanlar bo� iken ekleme yap�lamaz.',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='T�m alanlar bo� iken ekleme yap�lamaz.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='AllFieldsCannotBeEmptyInformationText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='AllFieldsCannotBeEmptyInformationText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','AllFieldsCannotBeEmptyInformationText','Additions cannot be made when all fields are empty.','Additions cannot be made when all fields are empty.',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Additions cannot be made when all fields are empty.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='AllFieldsCannotBeEmptyInformationText' and ChannelId=19 
	end

----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='IsOtherDocumentTypeNeedsDocumentText.InnerText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','IsOtherDocumentTypeNeedsDocumentText.InnerText','Fatura ve Di�er tipindeki d�k�manlar�n�z� opsiyonel olarak y�kleyebilirsiniz.Mal mukabili ithalat transferiniz i�in zorunlu olarak GB No ve Tarih bilgisi girmeniz gerekmektedir. Bu bilgiler ile i�lemi yapman�z yeterlidir.','IsOtherDocumentTypeNeedsDocumentText.InnerText',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Fatura ve Di�er tipindeki d�k�manlar�n�z� opsiyonel olarak y�kleyebilirsiniz.Mal mukabili ithalat transferiniz i�in zorunlu olarak GB No ve Tarih bilgisi girmeniz gerekmektedir. Bu bilgiler ile i�lemi yapman�z yeterlidir.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='IsOtherDocumentTypeNeedsDocumentText.InnerText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='IsOtherDocumentTypeNeedsDocumentText.InnerText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','IsOtherDocumentTypeNeedsDocumentText.InnerText','You can upload your invoice and other type documents optionally. You must enter the Customs Declaration Number and Date information for your import against goods. It is sufficient to do the transaction with this information.','IsOtherDocumentTypeNeedsDocumentText.InnerText',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You can upload your invoice and other type documents optionally. You must enter the Customs Declaration Number and Date information for your import against goods. It is sufficient to do the transaction with this information.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='IsOtherDocumentTypeNeedsDocumentText.InnerText' and ChannelId=19 
	end

------------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='IsRequiredDocumentUploadedText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','IsRequiredDocumentUploadedText','{0} �deme �ekli i�in {1} tipindeki dosyalar�n y�klenmesi zorunludur.','{0} �deme �ekli i�in {1} tipindeki dosyalar�n y�klenmesi zorunludur.',NULL,NULL,1,'Nov 16 2020  1:50PM',NULL,NULL,'T64513','Nov 16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='{0} �deme �ekli i�in {1} tipindeki dosyalar�n y�klenmesi zorunludur.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='IsRequiredDocumentUploadedText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='IsRequiredDocumentUploadedText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','IsRequiredDocumentUploadedText','For {0] payment type, you must upload this documents: {1}','For {0] payment type, you must upload this documents: {1}',NULL,NULL,1,'Nov 16 2020  1:50PM',NULL,NULL,'T64513','Nov 16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='For {0] payment type, you must upload this documents: {1}'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='IsRequiredDocumentUploadedText' and ChannelId=19 
	end

----------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='SameCustomDeclarationCannotAddInformationText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','SameCustomDeclarationCannotAddInformationText','Ayn� Beyanname Tarih ve Numaras�na sahip d�k�mans�z kay�t eklenemez.','Ayn� Beyanname Tarih ve Numaras�na sahip d�k�mans�z kay�t eklenemez.',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ayn� Beyanname Tarih ve Numaras�na sahip d�k�mans�z kay�t eklenemez.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='SameCustomDeclarationCannotAddInformationText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='SameCustomDeclarationCannotAddInformationText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','SameCustomDeclarationCannotAddInformationText','A record with the same Declaration Date and Number cannot be attached.','A record with the same Declaration Date and Number cannot be attached.',NULL,NULL,1,'Nov  16 2020  1:50PM',NULL,NULL,'T64513','Nov  16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='A record with the same Declaration Date and Number cannot be attached.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='SameCustomDeclarationCannotAddInformationText' and ChannelId=19 
	end

---------------------

update VpStringResource set ResourceValue='�u ana kadar girmi� oldu�unuz bilgiler ile taslak olu�turulacakt�r. Olu�an tasla��n�za ��lem Takibi men�s�nden ula�abilirsiniz. Onayl�yor musunuz?' where ResourceKey='CreateDraftConfirmText' and CultureCode='tr-TR'

update VpStringResource set ResourceValue='Tasla��n�z olu�turulmu�tur. ��lem Takibi men�s�nden ula�abilirsiniz.' where ResourceKey='CreateDraftSuccessInformationText' and CultureCode='tr-TR'

---------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='IsOtherDocumentTypeNeedsDocumentTooltipControl.ToolTip' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','tr-TR','IsOtherDocumentTypeNeedsDocumentTooltipControl.ToolTip','Fatura ve Di�er tipindeki d�k�manlar�n�z� opsiyonel olarak y�kleyebilirsiniz.Mal mukabili ithalat transferiniz i�in zorunlu olarak GB No ve Tarih bilgisi girmeniz gerekmektedir. Bu bilgiler ile i�lemi yapman�z yeterlidir.','',NULL,NULL,1,'Nov 16 2020  1:50PM',NULL,NULL,'T64513','Nov 16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Fatura ve Di�er tipindeki d�k�manlar�n�z� opsiyonel olarak y�kleyebilirsiniz.Mal mukabili ithalat transferiniz i�in zorunlu olarak GB No ve Tarih bilgisi girmeniz gerekmektedir. Bu bilgiler ile i�lemi yapman�z yeterlidir.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='tr-TR' and ResourceKey='IsOtherDocumentTypeNeedsDocumentTooltipControl.ToolTip' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='IsOtherDocumentTypeNeedsDocumentTooltipControl.ToolTip' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx','en-US','IsOtherDocumentTypeNeedsDocumentTooltipControl.ToolTip','You can upload your invoice and other type documents optionally. You must enter the Customs Declaration Number and Date information for your import against goods. It is sufficient to do the transaction with this information.','',NULL,NULL,1,'Nov 16 2020  1:50PM',NULL,NULL,'T64513','Nov 16 2020  1:50PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You can upload your invoice and other type documents optionally. You must enter the Customs Declaration Number and Date information for your import against goods. It is sufficient to do the transaction with this information.'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/NewOperation/Import/OperationDetailsEntry.aspx' and CultureCode='en-US' and ResourceKey='IsOtherDocumentTypeNeedsDocumentTooltipControl.ToolTip' and ChannelId=19 
	end