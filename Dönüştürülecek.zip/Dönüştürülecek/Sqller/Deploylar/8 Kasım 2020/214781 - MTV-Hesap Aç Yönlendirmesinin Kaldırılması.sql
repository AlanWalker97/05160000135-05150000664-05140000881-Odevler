--TaxMVPTransaction i�in olanlar--


delete from VpTransactionAdvice where CssClass='CreateCreditCardApplicationTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxMVPTransaction') and ChannelID=2

update VpTransactionAdvice set AdviceTransactionID = (select ID from vptransaction where TransactionName ='CreateCreditCardApplicationTransaction') , CssClass='CreateCreditCardApplicationTransaction' where  CssClass='AccountOpeningTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxMVPTransaction') and ChannelID=2

delete from VpTransactionAdvice where CssClass='AccountOpeningTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxMVPTransaction') and ChannelID=19

delete from VpStringResource where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.TaxMVPTransaction.1.CreateDemandDepositAccount'

update VpStringResource set ResourceValue='Kredi Kart� Se�imi' , FriendlyName='Kredi Kart� Se�imi' where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.TaxMVPTransaction.StepName.CardOrAccountSelection' and ChannelId=2

update VpStringResource set ResourceValue='Kredi Kart� Se�imi' , FriendlyName='Kredi Kart� Se�imi' where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.TaxMVPTransaction.StepName.CardOrAccountSelection' and ChannelId=19

update VpStringResource set ResourceValue='Credit Card Selection' , FriendlyName='Credit Card Selection' where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.TaxMVPTransaction.StepName.CardOrAccountSelection' and ChannelId=19

update VpStringResource set ResourceValue='Credit Card Selection' , FriendlyName='Credit Card Selection' where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.TaxMVPTransaction.StepName.CardOrAccountSelection' and ChannelId=2

update VpStringResource set ResourceValue='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' , FriendlyName='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxMVPTransaction.1' and CultureCode='tr-TR' and ChannelID=2

update VpStringResource set ResourceValue='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' , FriendlyName='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxMVPTransaction.1' and CultureCode='tr-TR' and ChannelID=19

update VpStringResource set ResourceValue='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' , FriendlyName='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxMVPTransaction.1' and CultureCode='en-US' and ChannelID=19

update VpStringResource set ResourceValue='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' , FriendlyName='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxMVPTransaction.1' and CultureCode='en-US' and ChannelID=2



--TaxOthersOnlineTransaction i�in olanlar--

delete from VpTransactionAdvice where CssClass='CreateCreditCardApplicationTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxOthersOnlineTransaction') and ChannelID=2

update VpTransactionAdvice set AdviceTransactionID = (select ID from vptransaction where TransactionName ='CreateCreditCardApplicationTransaction') , CssClass='CreateCreditCardApplicationTransaction' where  CssClass='AccountOpeningTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxOthersOnlineTransaction') and ChannelID=2

delete from VpTransactionAdvice where CssClass='AccountOpeningTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxOthersOnlineTransaction') and ChannelID=19

delete from VpStringResource where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.TaxOthersOnlineTransaction.1.CreateDemandDepositAccount'

update VpStringResource set ResourceValue='Kredi Kart� Se�imi' , FriendlyName='Kredi Kart� Se�imi' where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.TaxOthersOnlineTransaction.StepName.CardOrAccountSelection' and ChannelId=2

update VpStringResource set ResourceValue='Kredi Kart� Se�imi' , FriendlyName='Kredi Kart� Se�imi' where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.TaxOthersOnlineTransaction.StepName.CardOrAccountSelection' and ChannelId=19

update VpStringResource set ResourceValue='Credit Card Selection' , FriendlyName='Credit Card Selection' where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.TaxOthersOnlineTransaction.StepName.CardOrAccountSelection' and ChannelId=19

update VpStringResource set ResourceValue='Credit Card Selection' , FriendlyName='Credit Card Selection' where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.TaxOthersOnlineTransaction.StepName.CardOrAccountSelection' and ChannelId=2

update VpStringResource set ResourceValue='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' , FriendlyName='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxOthersOnlineTransaction.1' and CultureCode='tr-TR' and ChannelID=2

update VpStringResource set ResourceValue='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' , FriendlyName='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxOthersOnlineTransaction.1' and CultureCode='tr-TR' and ChannelID=19

update VpStringResource set ResourceValue='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' , FriendlyName='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxOthersOnlineTransaction.1' and CultureCode='en-US' and ChannelID=19

update VpStringResource set ResourceValue='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' , FriendlyName='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxOthersOnlineTransaction.1' and CultureCode='en-US' and ChannelID=2



--TaxOthersOfflineTransaction i�in olanlar--

delete from VpTransactionAdvice where CssClass='CreateCreditCardApplicationTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxOthersOfflineTransaction') and ChannelID=2

update VpTransactionAdvice set AdviceTransactionID = (select ID from vptransaction where TransactionName ='CreateCreditCardApplicationTransaction') , CssClass='CreateCreditCardApplicationTransaction' where  CssClass='AccountOpeningTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxOthersOfflineTransaction') and ChannelID=2

delete from VpTransactionAdvice where CssClass='AccountOpeningTransaction' and TransactionID=(select ID from vptransaction where TransactionName ='TaxOthersOfflineTransaction') and ChannelID=19

delete from VpStringResource where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.TaxOthersOfflineTransaction.1.CreateDemandDepositAccount'

update VpStringResource set ResourceValue='Kredi Kart� Se�imi' , FriendlyName='Kredi Kart� Se�imi' where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.TaxOthersOfflineTransaction.StepName.CardOrAccountSelection' and ChannelId=2

update VpStringResource set ResourceValue='Kredi Kart� Se�imi' , FriendlyName='Kredi Kart� Se�imi' where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.TaxOthersOfflineTransaction.StepName.CardOrAccountSelection' and ChannelId=19

update VpStringResource set ResourceValue='Credit Card Selection' , FriendlyName='Credit Card Selection' where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.TaxOthersOfflineTransaction.StepName.CardOrAccountSelection' and ChannelId=19

update VpStringResource set ResourceValue='Credit Card Selection' , FriendlyName='Credit Card Selection' where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.TaxOthersOfflineTransaction.StepName.CardOrAccountSelection' and ChannelId=2

update VpStringResource set ResourceValue='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' , FriendlyName='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxOthersOfflineTransaction.1' and CultureCode='tr-TR' and ChannelID=2

update VpStringResource set ResourceValue='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' , FriendlyName='Bu i�lem i�in uygun bir kredi kart�n�z bulunmuyor. 01.01.2020 itibar�yla ge�erli olan yeni yasal d�zenlemeler nedeniyle vergi �demelerinizi sadece kredi kart�n�z� kullanarak yapabilirsiniz.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxOthersOfflineTransaction.1' and CultureCode='tr-TR' and ChannelID=19

update VpStringResource set ResourceValue='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' , FriendlyName='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxOthersOfflineTransaction.1' and CultureCode='en-US' and ChannelID=19

update VpStringResource set ResourceValue='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' , FriendlyName='You do not have an eligible credit card for this transaction. Due to the new legal regulations that are valid as of 01.01.2020, you can make your tax payments only by using your credit cards.' where ResourceType='GeneralResource' and ResourceKey='COMMONADVICE.HEADER.TaxOthersOfflineTransaction.1' and CultureCode='en-US' and ChannelID=2
