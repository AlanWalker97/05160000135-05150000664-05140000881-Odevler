if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentDetailGridViewBcBillNumber.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx','tr-TR','PaymentDetailGridViewBcBillNumber.HeaderText','Fatura Numaras�','Fatura Numaras�',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Fatura Numaras�'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentDetailGridViewBcBillNumber.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='en-US' and ResourceKey='PaymentDetailGridViewBcBillNumber.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx','en-US','PaymentDetailGridViewBcBillNumber.HeaderText','Fatura Numaras�','Fatura Numaras�',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Fatura Numaras�'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='en-US' and ResourceKey='PaymentDetailGridViewBcBillNumber.HeaderText' and ChannelId=19 
	end





	if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentDetailGridViewBcReceiverSwiftCode.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx','tr-TR','PaymentDetailGridViewBcReceiverSwiftCode.HeaderText','Al�c� Swift Kodu','Al�c� Swift Kodu',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Al�c� Swift Kodu'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentDetailGridViewBcReceiverSwiftCode.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='en-US' and ResourceKey='PaymentDetailGridViewBcReceiverSwiftCode.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx','en-US','PaymentDetailGridViewBcReceiverSwiftCode.HeaderText','Al�c� Swift Kodu','Al�c� Swift Kodu',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Fatura Numaras�'
			where ResourceType='WebApplication.UI/Transactions/MoneyTransfer/MultiForeignExchangeTransfer/Payments/PaymentDetail.aspx' and CultureCode='en-US' and ResourceKey='PaymentDetailGridViewBcReceiverSwiftCode.HeaderText' and ChannelId=19 
	end





	if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ReceiverSwiftCode' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','ReceiverSwiftCode','Al�c� Swift Kodu','Al�c� Swift Kodu :',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Al�c� Swift Kodu'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='ReceiverSwiftCode' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ReceiverSwiftCode' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','ReceiverSwiftCode','Al�c� Swift Kodu','Al�c� Swift Kodu :',NULL,'',1,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Al�c� Swift Kodu'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='ReceiverSwiftCode' and ChannelId=19 
	end
