if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/MyTransactions/ForeignTradeMyTransactions.aspx' and CultureCode='en-US' and ResourceKey='OngoingForeignTradeTransferTypeIBKBText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/MyTransactions/ForeignTradeMyTransactions.aspx','en-US','OngoingForeignTradeTransferTypeIBKBText','�hracat Bedeli Kabul Belgesi','�hracat Bedeli Kabul Belgesi',NULL,'�hracat Bedeli Kabul Belgesi',1,'Jul 12 2019 10:02AM','FINANS\S61434',NULL,'FINANS\S61434','Jul 12 2019 10:02AM','Jul 12 2019 10:02AM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�hracat Bedeli Kabul Belgesi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/MyTransactions/ForeignTradeMyTransactions.aspx' and CultureCode='en-US' and ResourceKey='OngoingForeignTradeTransferTypeIBKBText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/ForeignTrade/MyTransactions/ForeignTradeMyTransactions.aspx' and CultureCode='tr-TR' and ResourceKey='OngoingForeignTradeTransferTypeIBKBText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/ForeignTrade/MyTransactions/ForeignTradeMyTransactions.aspx','tr-TR','OngoingForeignTradeTransferTypeIBKBText','�hracat Bedeli Kabul Belgesi','�hracat Bedeli Kabul Belgesi',NULL,'�hracat Bedeli Kabul Belgesi',1,'Jul 12 2019 10:02AM','FINANS\S61434',NULL,'FINANS\S61434','Jul 12 2019 10:02AM','Jul 12 2019 10:02AM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�hracat Bedeli Kabul Belgesi'
			where ResourceType='WebApplication.UI/Transactions/ForeignTrade/MyTransactions/ForeignTradeMyTransactions.aspx' and CultureCode='tr-TR' and ResourceKey='OngoingForeignTradeTransferTypeIBKBText' and ChannelId=19 
	end