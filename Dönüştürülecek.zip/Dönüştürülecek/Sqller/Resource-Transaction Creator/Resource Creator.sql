---*******
--- String Resource olu�turma beti�i, id bilgisini ver sana gerekli scriptti donsun :)
-- Nas�l Cal�s�r ?
-- Cursor'daki id bilgisinin oldu�u yere sadece Resource Id bilgisini eklememiz yeterli olacakt�r. O id bilgilerine g�re resourcelar otomatik olarak olu�turulacak. veya subQuery yazarak id bilgilerini besleyebilirsiniz.
-- Olusan scriptleri diger ortamlara da yayabiliriz. 
-- @UseUpdateFlag : Mevcutta var, insert etmiyoruz? Peki ya update edecek miyiz ? E�er ki mevcutlar� update etmek istiyorsak bu flag =1 olmal�, aksi durumda 0 verilmeli. Default De�erimiz : 0 
--********************************************************************************************************************************************************************************************************************************
--********************************************************************************************************************************************************************************************************************************
	declare @UseUpdateFlag bit
	declare @sqlString Nvarchar(max)
	
	declare @ResourceType varchar(255) ,
			@CultureCode nvarchar(5) ,
			@ResourceKey varchar(511) ,
			@ResourceValue varchar(max) ,
			@FriendlyName varchar(250) ,
			@TransactionID bigint ,
			@NewResourceValue varchar(max),
			@Status tinyint,
			@LastAccessTime datetime,
			@CheckedBy varchar(51) ,
			@Comment varchar(127),
			@ModifyBy varchar(127),
			@ModifyDate datetime,
			@CheckedDate datetime,
			@IsDeleted bit,
			@CategoryID bigint,
			@ChannelID bigint
	
	
	
	set @UseUpdateFlag=1
	
	declare c cursor for select ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,
								ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID 
						 from VpStringResource(nolock) where ID in (
						 
						1045984,1045985
						 
						 ) /*Resource ID bilgilerini buraya set edelim. veya subquery ile id bilgilerini besleyelim.*/ 
	open c 
		fetch next from c into	@ResourceType ,@CultureCode,@ResourceKey,@ResourceValue,@FriendlyName,
								@TransactionID,@NewResourceValue,@Status,@LastAccessTime,@CheckedBy,@Comment,
								@ModifyBy,@ModifyDate,@CheckedDate,@IsDeleted,@CategoryID,@ChannelID
		while @@FETCH_STATUS=0
			begin
			
			set @sqlString=N'if not Exists(select 1 from vpStringResource(nolock) where '
				set @sqlString=@sqlString+'ResourceType='''+@ResourceType+''' and CultureCode='''+@CultureCode+''' and ResourceKey='''+@ResourceKey+''' and ChannelId='+convert(nvarchar,@ChannelID)+') '
				set @sqlString=@sqlString+'
	begin '
				set @sqlString=@sqlString+'
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) '
				set @sqlString=@sqlString+N'
				values('+ (case when @ResourceType is null then +'NULL'else +''''+@ResourceType+'''' end)
				set @sqlString=@sqlString+N','+ (case when @CultureCode is null then +'NULL'else +''''+@CultureCode+'''' end)
				set @sqlString=@sqlString+N','+ (case when @ResourceKey is null then +'NULL'else +''''+@ResourceKey+'''' end)
				set @sqlString=@sqlString+N','+ (case when @ResourceValue is null then +'NULL'else +''''+REPLACE(@ResourceValue,'''','''''')+'''' end)
				set @sqlString=@sqlString+N','+ (case when @FriendlyName is null then +'NULL'else +''''+REPLACE(@FriendlyName,'''','''''')+'''' end)
				set @sqlString=@sqlString+N','+ (case when @TransactionID is null then +'NULL'else +''''+convert(nvarchar,@TransactionID)+'''' end)
				set @sqlString=@sqlString+N','+ (case when @NewResourceValue is null then +'NULL'else +''''+@NewResourceValue+'''' end)
				set @sqlString=@sqlString+N','+ (case when @Status is null then +'NULL'else +''+Convert(nvarchar,@Status)+'' end)
				set @sqlString=@sqlString+N','+ (''''+Convert(nvarchar,GETDATE())+'''')
				set @sqlString=@sqlString+N','+ (case when @CheckedBy is null then +'NULL'else +''''+@CheckedBy+'''' end)
				set @sqlString=@sqlString+N','+ (case when @Comment is null then +'NULL'else +''''+@Comment+'''' end)
				set @sqlString=@sqlString+N','+ (''''+'T64513'+'''')
				set @sqlString=@sqlString+N','+ (''''+Convert(nvarchar,GETDATE())+'''')
				set @sqlString=@sqlString+N','+ (case when @CheckedDate is null then +'NULL'else +''''+convert(nvarchar,@CheckedDate)+'''' end)
				set @sqlString=@sqlString+N','+ (case when @IsDeleted is null then +'NULL'else +''''+convert(nvarchar,@IsDeleted)+'''' end)
				set @sqlString=@sqlString+N','+ (case when @CategoryID is null then +'NULL'else +''''+convert(nvarchar,@CategoryID)+'''' end)
				set @sqlString=@sqlString+N','+ (case when @ChannelID is null then +'NULL'else +''''+convert(nvarchar,@ChannelID)+'''' end)
				set @sqlString=@sqlString+N') 
	end '
	if @UseUpdateFlag=1 
	begin
	set @sqlString=@sqlString+N'
	else 
	begin'
		set @sqlString=@sqlString+N'
			update vpStringResource Set ResourceValue='''+convert(nvarchar(max),REPLACE(@ResourceValue,'''','''''')) +'''' +', FriendlyName=''' + convert(nvarchar(max),REPLACE(@ResourceValue,'''','''''')) + ''''
		set @sqlString=@sqlString+N'
			where '
		set @sqlString=@sqlString+'ResourceType='''+@ResourceType+''' and CultureCode='''+@CultureCode+''' and ResourceKey='''+@ResourceKey+''' and ChannelId='+convert(nvarchar,@ChannelID)+' '
		set @sqlString=@sqlString+N'
	end'
	end		
				print @sqlString
				fetch next from c into	@ResourceType ,@CultureCode,@ResourceKey,@ResourceValue,@FriendlyName,
										@TransactionID,@NewResourceValue,@Status,@LastAccessTime,@CheckedBy,@Comment,
										@ModifyBy,@ModifyDate,@CheckedDate,@IsDeleted,@CategoryID,@ChannelID

			end
	
	close c
	deallocate c