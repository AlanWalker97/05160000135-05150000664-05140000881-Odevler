﻿select * from VpHostCallMappingDetail  
where HostCallMappingID = (select top 1 HostCallMappingID from VpVeriBranchTransactionMapping 
where VeribranchTransactionName = 'LoanInstallmentPaymentForCorporate')  
order by VeribranchTransactionPropertyType 

select * from VpHostCallMappingDetail  
where HostCallMappingID = (select top 1 HostCallMappingID from VpVeriBranchTransactionMapping 
where VeribranchTransactionName = 'GetBCHAndInstallmentLoans')   
order by HostCallMappingType 

select * from VpTransactionTemplateConfig where Name='LoanInstallmentPaymentForCorporateTemplate'

select * from VpTransactionConfirmMessages where TransactionID=(select ID from VpTransaction where TransactionName ='LoanInstallmentPaymentForCorporate' )

select * from VpTransaction where ID='2139'

select * from VpTransactionConfig where TransactionID in(select ID from vptransaction where TransactionName ='LoanInstallmentPaymentForCorporate') 

select * from VpStringResource where ResourceKey like '%LoanInstallmentPaymentForCorporate%' and CultureCode='tr-TR'

select * from VpStringResource where ResourceValue like '%Döküman bulunamadý%'

select * from VpStringResource where ResourceKey like 'EXECUTE.SUCCESS%' and ResourceValue like '%{0}%'

select * from VpTransactionAdvice where CssClass='GetSelectedFehasInfo' and ChannelID=19 and TransactionID in(select ID from vptransaction where TransactionName ='LoanInstallmentPaymentForCorporate') 

select * from VpTransactionAdvice where Condition is not null

select * from VpStringResource where ResourceKey='InstallmentEarlyCloseAmountText' and ResourceType='LoanInstallmentPaymentForCorporate.CONFIRM'

------------------
update VpStringResource set ResourceValue='{0}', FriendlyName='', ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' where ResourceKey='EXECUTE.SUCCESS.LoanInstallmentPaymentForCorporate'

update VpTransactionTemplateConfig set Configuration='<?xml version="1.0" encoding="utf-8" ?>  <PageTemplates xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://tempuri.org/VeriBranchMessages.xsd">   <PageTemplate ID="Confirm"  HtmlTemplateName="ConfirmPageHTMLTemplate">    <InformationContainer HeaderResourceKey="SourceAccountHeader" HeaderResourceType="Database">     <Row  TitleResourceKey="SourceAccountName" DataKey="SourceAccountName" ConditionSource="TransactionHeader" TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="SourceIBAN" DataKey="SourceAccount.IBAN" DataFormatMethod="ToIban" ConditionSource="TransactionHeader" TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="SourceBalance" DataFormatMethod="ToMoneyWithCurrency" DataKey="SourceAccount.Balance.Value,SourceAccount.Balance.Currency.Name" ConditionSource="TransactionHeader" TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="SourceAvailableBalance" DataFormatMethod="ToMoneyWithCurrency" DataKey="SourceAccount.AvailableBalance.Value,SourceAccount.AvailableBalance.Currency.Name" ConditionSource="TransactionHeader" TitleResourceType="Database" InformationItemType="Big" />    </InformationContainer>    <InformationContainer HeaderResourceKey="PaymentInfoHeader" HeaderResourceType="Database">     <Row  TitleResourceKey="PaymentTypeText" DataKey="LoanSubTypeName" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="PaymentNoText" DataKey="Loan.LoanNo" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="InstallmentCountsText" DataKey="InstallmentCountText" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="InstallmentDateText" DataKey="NextInstallmentPaymentDate" DataFormatMethod="ToShortDate" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="PaymentDateText" DataKey="PaymentDate" DataFormatMethod="ToShortDate" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="PaymentDateEarlyCloseText" DataKey="PaymentEarlyCloseDate" DataFormatMethod="ToShortDate" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="InstallmentAmountText" DataKey="InstallmentPaymentAmount.Value,InstallmentPaymentAmount.Currency.Name" DataFormatMethod="ToMoneyWithCurrency" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="InstallmentEarlyCloseAmountText" DataKey="InstallmentEarlyCloseAmount.Value,InstallmentEarlyCloseAmount.Currency.Name" DataFormatMethod="ToMoneyWithCurrency" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />        <Row  TitleResourceKey="RemainingClosureDiscount" DataKey="RemainingClosureDiscount" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="EarlyCloseDiscount" DataKey="EarlyCloseDiscount" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="RemainingClosureDiff" DataKey="RemainingClosureDiff" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="EarlyCloseValue" DataKey="EarlyCloseValue" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />     <Row  TitleResourceKey="PaymentAmountText" DataKey="Amount.Value,Amount.Currency.Name" DataFormatMethod="ToMoneyWithCurrency" ConditionSource="TransactionHeader"  TitleResourceType="Database" InformationItemType="Big" />    </InformationContainer>    <Row ControlUrl = "~/Transactions/Loans/LoanPaymentForCorporate/LoanPaymentConfirm.ascx"/>   </PageTemplate>   <PageTemplate ID="Execute"  HtmlTemplateName="ExecutePageHTMLTemplate" UseCommonExecutePage="true"></PageTemplate>  </PageTemplates>' where Name='LoanInstallmentPaymentForCorporateTemplate'

update VpTransactionAdvice set ConditionSource=0 , Condition='IsAnyLoanLeftWithEarlyClosing==true' where CssClass='GetSelectedFehasInfo' and ChannelID=19 and TransactionID in(select ID from vptransaction where TransactionName ='LoanInstallmentPaymentForCorporate')
------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='InstallmentPayment' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','tr-TR','InstallmentPayment','Taksit Ödemesi','Taksit Ödemesi',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Taksit Ödemesi', FriendlyName='Taksit Ödemesi'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='InstallmentPayment' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='InstallmentPayment' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','en-US','InstallmentPayment','Installment Payment','Installment Payment',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Installment Payment', FriendlyName='Installment Payment'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='InstallmentPayment' and ChannelId=19 
	end

-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='EarlySettlement' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','tr-TR','EarlySettlement','Erken Kapama','Erken Kapama',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Erken Kapama', FriendlyName='Erken Kapama'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='EarlySettlement' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='EarlySettlement' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','en-US','EarlySettlement','Early Settlement','Early Settlement',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Early Settlement', FriendlyName='Early Settlement'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='EarlySettlement' and ChannelId=19 
	end

-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='LoanPayment' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','tr-TR','LoanPayment','Kredi Ödemesi','Kredi Ödemesi',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kredi Ödemesi', FriendlyName='Kredi Ödemesi'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='LoanPayment' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='LoanPayment' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','en-US','LoanPayment','Loan Payment','Loan Payment',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Loan Payment', FriendlyName='Loan Payment'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='LoanPayment' and ChannelId=19 
	end

-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentSuccessfulMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','tr-TR','PaymentSuccessfulMessage','Kredi ödemeniz baþarýyla tamamlanmýþtýr.','Kredi ödemeniz baþarýyla tamamlanmýþtýr.',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kredi ödemeniz baþarıyla tamamlanmýþtýr.', FriendlyName='Kredi ödemeniz baþarýyla tamamlanmýþtýr.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentSuccessfulMessage' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='PaymentSuccessfulMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','en-US','PaymentSuccessfulMessage','Loan payment has been completed.','Loan payment has been completed.',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Loan payment has been completed.', FriendlyName='Loan payment has been completed.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='PaymentSuccessfulMessage' and ChannelId=19 
	end

-----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='LoanClosingMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','tr-TR','LoanClosingMessage','{0} numaralý krediniz kapatýlmýþtýr.','{0} numaralý krediniz kapatýlmýþtýr.',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='{0} numaralý krediniz kapatýlmýþtýr.', FriendlyName='{0} numaralý krediniz kapatýlmýþtýr.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='tr-TR' and ResourceKey='LoanClosingMessage' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='LoanClosingMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx','en-US','LoanClosingMessage','Your credit number {0} has been closed.','Your credit number {0} has been closed.',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Your credit number {0} has been closed.', FriendlyName='Your credit number {0} has been closed.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanSelection.aspx' and CultureCode='en-US' and ResourceKey='LoanClosingMessage' and ChannelId=19 
	end

-----------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='LoanPayment' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','LoanPayment','Kredi Ödemesi','Kredi Ödemesi',NULL,'',1,'Jun  1 2021  4:22PM',NULL,NULL,'T64513','Jun  1 2021  4:22PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kredi Ödemesi', FriendlyName='Kredi Ödemesi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='LoanPayment' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='LoanPayment' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','LoanPayment','Loan Payment','Loan Payment',NULL,'',1,'Jun  1 2021  4:22PM',NULL,NULL,'T64513','Jun  1 2021  4:22PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Loan Payment', FriendlyName='Loan Payment'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='LoanPayment' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' and CultureCode='en-US' and ResourceKey='EarlyClosingHeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx','en-US','EarlyClosingHeaderText','Please select the account from which the {1} numbered {0}''s early closing amount {2} would be taken.','Please select the account from which the {1} numbered {0}''s early closing amount {2} would be taken.',NULL,'',1,'Jun  2 2021 11:06AM',NULL,NULL,'T64513','Jun  2 2021 11:06AM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Please select the account from which the {1} numbered {0}''s early closing amount {2} would be taken.', FriendlyName='Please select the account from which the {1} numbered {0}''s early closing amount {2} would be taken.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' and CultureCode='en-US' and ResourceKey='EarlyClosingHeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' and CultureCode='tr-TR' and ResourceKey='EarlyClosingHeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx','tr-TR','EarlyClosingHeaderText','Lütfen {0} numaralý {1} erken kapama tutarý olan {2}''nin alýnacaðý hesabý seçiniz.','Lütfen {0} numaralý {1} erken kapama tutarý olan {2}''nin alýnacaðý hesabý seçiniz.',NULL,'',1,'Jun  2 2021 11:06AM',NULL,NULL,'T64513','Jun  2 2021 11:06AM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Lütfen {0} numaralý {1} erken kapama tutarý olan {2}''nin alýnacaðý hesabý seçiniz.', FriendlyName='Lütfen {0} numaralý {1} erken kapama tutarý olan {2}''nin alýnacaðý hesabý seçiniz.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' and CultureCode='tr-TR' and ResourceKey='EarlyClosingHeaderText' and ChannelId=19 
	end

----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanPaymentConfirm.ascx' and CultureCode='en-US' and ResourceKey='EarlyClosingConfirmLabelText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanPaymentConfirm.ascx','en-US','EarlyClosingConfirmLabelText','Since you close your loan early, an early closing commission of {0}% will be charged over your remaining loan principal amount.','Since you close your loan early, an early closing commission of {0}% will be charged over your remaining loan principal amount.',NULL,'',1,'Jun  2 2021 11:06AM',NULL,NULL,'T64513','Jun  2 2021 11:06AM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Since you close your loan early, an early closing commission of {0}% will be charged over your remaining loan principal amount.', FriendlyName='Since you close your loan early, an early closing commission of {0}% will be charged over your remaining loan principal amount.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanPaymentConfirm.ascx' and CultureCode='en-US' and ResourceKey='EarlyClosingConfirmLabelText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanPaymentConfirm.ascx' and CultureCode='tr-TR' and ResourceKey='EarlyClosingConfirmLabelText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanPaymentConfirm.ascx','tr-TR','EarlyClosingConfirmLabelText','Kredinizi erken kapattýðýnýz için kalan kredi anapara tutarýnýz üzerinden %{0} oranýnda erken kapama komisyonu tahsil edilecektir.','Kredinizi erken kapattýðýnýz için kalan kredi anapara tutarýnýz üzerinden %{0} oranýnda erken kapama komisyonu tahsil edilecektir.',NULL,'',1,'Jun  2 2021 11:06AM',NULL,NULL,'T64513','Jun  2 2021 11:06AM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kredinizi erken kapattýðýnýz için kalan kredi anapara tutarýnýz üzerinden %{0} oranýnda erken kapama komisyonu tahsil edilecektir.', FriendlyName='Kredinizi erken kapattýðýnýz için kalan kredi anapara tutarýnýz üzerinden %{0} oranýnda erken kapama komisyonu tahsil edilecektir.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/LoanPaymentConfirm.ascx' and CultureCode='tr-TR' and ResourceKey='EarlyClosingConfirmLabelText' and ChannelId=19 
	end

----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' and CultureCode='tr-TR' and ResourceKey='LoanClosingMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx','tr-TR','LoanClosingMessage','{0} numaralý krediniz kapatýlmýþtýr.','{0} numaralý krediniz kapatýlmýþtýr.',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='{0} numaralý krediniz kapatýlmýþtýr.', FriendlyName='{0} numaralý krediniz kapatýlmýþtýr.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' and CultureCode='tr-TR' and ResourceKey='LoanClosingMessage' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' and CultureCode='en-US' and ResourceKey='LoanClosingMessage' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx','en-US','LoanClosingMessage','Your credit number {0} has been closed.','Your credit number {0} has been closed.',NULL,'',1,'May 24 2021  3:48PM',NULL,NULL,'T64513','May 24 2021  3:48PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Your credit number {0} has been closed.', FriendlyName='Your credit number {0} has been closed.'
			where ResourceType='WebApplication.UI/Transactions/Loans/LoanPaymentForCorporate/AccountSelection.aspx' and CultureCode='en-US' and ResourceKey='LoanClosingMessage' and ChannelId=19 
	end

-----------------