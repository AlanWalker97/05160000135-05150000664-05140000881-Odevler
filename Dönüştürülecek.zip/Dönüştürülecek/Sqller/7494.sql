IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = 'GetCommitmentCommissionAccruePeriodDailySummary')  BEGIN   INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],  [IsFinancial]  ,[IsInquiry],[HostGroupType]  ,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])  VALUES('GetCommitmentCommissionAccruePeriodDailySummary','Taahh�t Komisyonu Tahakkuk D�nemi G�nl�k �zeti Listele',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL)  END

IF NOT EXISTS (select * from VpTransactionAttributes where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetCommitmentCommissionAccruePeriodDailySummary'))  BEGIN  INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,  IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)  VALUES((select ID from VpTransaction where TransactionName = 'GetCommitmentCommissionAccruePeriodDailySummary'),  19,  0,  0,  NULL,  1  ,1111,  NULL,  1,  NULL,  11,  '080100',  'GetCommitmentCommissionAccruePeriodDailySummaryDesc')  END

IF NOT EXISTS(select * from VpTransactionConfig where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetCommitmentCommissionAccruePeriodDailySummary'))  BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)  VALUES((select ID from VpTransaction where TransactionName = 'GetCommitmentCommissionAccruePeriodDailySummary'),'<?xml version="1.0" encoding="utf-8" ?>    <TransactionConfig xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns="http://tempuri.org/VeriBranchMessages.xsd"><TransactionFlow>        <Step Name="Start" Action="RedirectToPage" Url="~/Transactions/Loans/CashFlowAndRiskBalance/CashFlowAndRiskBalanceStatusScreen.aspx" StepNameResourceKey="StepName.Start"></Step> </TransactionFlow>    <ImplementationData>         <RequestType>VeriBranch.Common.MessageDefinitions.GetCommitmentCommissionAccruePeriodDailySummaryRequest, VeriBranch.Common.MessageDefinitions</RequestType>         <ResponseType>VeriBranch.Common.MessageDefinitions.GetCommitmentCommissionAccruePeriodDailySummaryResponse, VeriBranch.Common.MessageDefinitions</ResponseType>         <ClassType>Finansbank.Business.Transactions.HostIntegrationTransaction, Finansbank.Business.Transactions</ClassType>       </ImplementationData>       <Name>GetCommitmentCommissionAccruePeriodDailySummary</Name><Simulate>false</Simulate></TransactionConfig>',  NULL,getdate(),'T64513',19) END

IF NOT EXISTS(select * from VpMenu where Title = 'Nakit Ak�� Risk Dengesi') BEGIN INSERT INTO [VpMenu]([ParentID],[MenuID],[MenuActionTypeID],[Title],[EnTitle],[Description],[OperationCode],[IsTransaction],[Url],[JavaScript],[IsTrimmingEnabled],[OrderIndex],[CssClass],[EnCssClass],[HostProcessCode],[ShowInTurkish],[ShowInEnglish],[MenuNickName],[EnMenuNickname],[MenuTooltip],[EnMenuTooltip],[MenuKeywords],[EnMenuKeywords],[ProductBadgeName],[EnProductBadgeName],[Roles],[IsBackOfficeMenu],[ChannelID],[ColorCode],[NewFlagExpireDate]) VALUES((select ParentID from VpMenu where Title='Kredi Kullan�m' and ChannelID=19),(select MenuID from VpMenu where Title='Kredi Kullan�m' and ChannelID=19),(select MenuActionTypeID from VpMenu where Title='Kredi Kullan�m' and ChannelID=19),'Nakit Ak�� Risk Dengesi','Cash Flow Risk Balance','Nakit Ak�� Risk Dengesi','-',1,'GetCommitmentCommissionAccruePeriodDailySummary','-',0,7,NULL,NULL,'080100',1,1,'-','-','-','-','-','-','-','-','-',NULL,19,NULL,NULL) END

-------------------------
IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = 'GetCashFlowSummaryTransaction')  BEGIN   INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],  [IsFinancial]  ,[IsInquiry],[HostGroupType]  ,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])  VALUES('GetCashFlowSummaryTransaction','Nakit Ak��� �zeti',NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL)  END

IF NOT EXISTS (select * from VpTransactionAttributes where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetCashFlowSummaryTransaction'))  BEGIN  INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,  IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)  VALUES((select ID from VpTransaction where TransactionName = 'GetCashFlowSummaryTransaction'),  19,  0,  0,  NULL,  1  ,1111,  NULL,  1,  NULL,  11,  '080100',  'Nakit Ak��� �zeti')  END

IF NOT EXISTS(select * from VpTransactionConfig where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetCashFlowSummaryTransaction'))  BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)  VALUES((select ID from VpTransaction where TransactionName = 'GetCashFlowSummaryTransaction'),'<?xml version="1.0" encoding="utf-8" ?>  <TransactionConfig   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"   xmlns:xsd="http://www.w3.org/2001/XMLSchema"   xmlns="http://tempuri.org/VeriBranchMessages.xsd">    <TransactionFlow>      <Step Name="Start" Action = "RedirectToPage" Url = "~/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx" StepNameResourceKey = "StepName.Start"></Step>    </TransactionFlow>    <ImplementationData>      <RequestType>VeriBranch.Common.MessageDefinitions.DummyRequest, VeriBranch.Common.MessageDefinitions</RequestType>      <ResponseType>VeriBranch.Common.MessageDefinitions.DummyResponse, VeriBranch.Common.MessageDefinitions</ResponseType>      <ClassType>Finansbank.Business.Transactions.HostIntegrationTransaction, Finansbank.Business.Transactions</ClassType>    </ImplementationData>    <Name>GetCashFlowSummaryTransaction</Name>    <Simulate>false</Simulate>  </TransactionConfig>',  NULL,getdate(),'T64513',19) END
-------------------------
IF NOT EXISTS (SELECT * from VpTransaction where TransactionName = 'GetRiskAmountSummaryTransaction')  BEGIN   INSERT INTO [VpTransaction]([TransactionName],[Description],[TransactionTypeId],  [IsFinancial]  ,[IsInquiry],[HostGroupType]  ,[isCross],[isLead],[isVirtual],[IsInternetBankingTransaction],[IsTransactionBasedLoggingEnabled])  VALUES('GetRiskAmountSummaryTransaction','Risk Tutar� �zeti',NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL)  END

IF NOT EXISTS (select * from VpTransactionAttributes where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetRiskAmountSummaryTransaction'))  BEGIN  INSERT INTO VpTransactionAttributes(TransactionID,ChannelID,IsDeleted,IsOTPRequired,FraudType,IsHistoryLoggingEnabled,LoggingVerbosity,  IsPerformanceCounterEnabled,IsEnabled,FraudState,HostCallLogVerbosity,HostProcessCode,DescriptionForChannel)  VALUES((select ID from VpTransaction where TransactionName = 'GetRiskAmountSummaryTransaction'),  19,  0,  0,  NULL,  1  ,1111,  NULL,  1,  NULL,  11,  '080100',  'Risk Tutar� �zeti')  END

IF NOT EXISTS(select * from VpTransactionConfig where   ChannelID = 19 and   TransactionID =   (select ID from VpTransaction where TransactionName = 'GetRiskAmountSummaryTransaction'))  BEGIN INSERT INTO VpTransactionConfig(TransactionID,Configuration,ChannelProductOID,CreateDate,CreateBy,ChannelID)  VALUES((select ID from VpTransaction where TransactionName = 'GetRiskAmountSummaryTransaction'),'<?xml version="1.0" encoding="utf-8" ?>  <TransactionConfig   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"   xmlns:xsd="http://www.w3.org/2001/XMLSchema"   xmlns="http://tempuri.org/VeriBranchMessages.xsd">    <TransactionFlow>      <Step Name="Start" Action = "RedirectToPage" Url = "~/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx" StepNameResourceKey = "StepName.Start"></Step>    </TransactionFlow>    <ImplementationData>      <RequestType>VeriBranch.Common.MessageDefinitions.DummyRequest, VeriBranch.Common.MessageDefinitions</RequestType>      <ResponseType>VeriBranch.Common.MessageDefinitions.DummyResponse, VeriBranch.Common.MessageDefinitions</ResponseType>      <ClassType>Finansbank.Business.Transactions.HostIntegrationTransaction, Finansbank.Business.Transactions</ClassType>    </ImplementationData>    <Name>GetRiskAmountSummaryTransaction</Name>    <Simulate>false</Simulate>  </TransactionConfig>',  NULL,getdate(),'T64513',19) END

-------------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetCommitmentCommissionAccruePeriodDailySummary' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','HEADER.GetCommitmentCommissionAccruePeriodDailySummary','Nakit Ak��� Risk Dengesi','Nakit Ak��� Risk Dengesi',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit Ak��� Risk Dengesi'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetCommitmentCommissionAccruePeriodDailySummary' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetCommitmentCommissionAccruePeriodDailySummary' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','HEADER.GetCommitmentCommissionAccruePeriodDailySummary','Cash Flow Risk Balance','Cash Flow Risk Balance',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Cash Flow Risk Balance'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetCommitmentCommissionAccruePeriodDailySummary' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetCashFlowSummaryTransaction' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','HEADER.GetCashFlowSummaryTransaction','Nakit Ak���','Nakit Ak���',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit Ak���'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetCashFlowSummaryTransaction' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetCashFlowSummaryTransaction' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','HEADER.GetCashFlowSummaryTransaction','Cash Flow','Cash Flow',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Cash Flow'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetCashFlowSummaryTransaction' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetRiskAmountSummaryTransaction' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','HEADER.GetRiskAmountSummaryTransaction','Risk Tutar�','Risk Tutar�',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Risk Tutar�'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetRiskAmountSummaryTransaction' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetRiskAmountSummaryTransaction' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','HEADER.GetRiskAmountSummaryTransaction','Risk Amount','Risk Amount',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Risk Amount'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetRiskAmountSummaryTransaction' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetCommitmentCommissionAccruePeriodDailySummary.StepName.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','HEADER.GetCommitmentCommissionAccruePeriodDailySummary.StepName.Start','G�zlem','G�zlem',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='G�zlem'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetCommitmentCommissionAccruePeriodDailySummary.StepName.Start' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetCommitmentCommissionAccruePeriodDailySummary.StepName.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','HEADER.GetCommitmentCommissionAccruePeriodDailySummary.StepName.Start','View','View',NULL,NULL,1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='View'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetCommitmentCommissionAccruePeriodDailySummary.StepName.Start' and ChannelId=19 
	end
---------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetCashFlowSummaryTransaction.StepName.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','HEADER.GetCashFlowSummaryTransaction.StepName.Start','','',NULL,'',1,'Apr 12 2021  3:24PM',NULL,NULL,'T64513','Apr 12 2021  3:24PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='', FriendlyName=''
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetCashFlowSummaryTransaction.StepName.Start' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetCashFlowSummaryTransaction.StepName.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','HEADER.GetCashFlowSummaryTransaction.StepName.Start','','',NULL,'',1,'Apr 12 2021  3:24PM',NULL,NULL,'T64513','Apr 12 2021  3:24PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='', FriendlyName=''
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetCashFlowSummaryTransaction.StepName.Start' and ChannelId=19 
	end
---------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetRiskAmountSummaryTransaction.StepName.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','HEADER.GetRiskAmountSummaryTransaction.StepName.Start','','',NULL,'',1,'Apr 12 2021  3:24PM',NULL,NULL,'T64513','Apr 12 2021  3:24PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='', FriendlyName=''
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='HEADER.GetRiskAmountSummaryTransaction.StepName.Start' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetRiskAmountSummaryTransaction.StepName.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','HEADER.GetRiskAmountSummaryTransaction.StepName.Start','','',NULL,'',1,'Apr 12 2021  3:24PM',NULL,NULL,'T64513','Apr 12 2021  3:24PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='', FriendlyName=''
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='HEADER.GetRiskAmountSummaryTransaction.StepName.Start' and ChannelId=19 
	end
---------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowHeaderItemText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryCashFlowHeaderItemText','Ayl�k Ortalama Nakit Ak��� Tutar�','Ayl�k Ortalama Nakit Ak��� Tutar�',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ayl�k Ortalama Nakit Ak��� Tutar�', FriendlyName='Ayl�k Ortalama Nakit Ak��� Tutar�'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowHeaderItemText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlowHeaderItemText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryCashFlowHeaderItemText','Monthly Average Cash Flow Amount','Monthly Average Cash Flow Amount',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Monthly Average Cash Flow Amount', FriendlyName='Monthly Average Cash Flow Amount'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlowHeaderItemText' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowPaymentsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryCashFlowPaymentsText','�demeler','�demeler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�demeler', FriendlyName='�demeler'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowPaymentsText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlowPaymentsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryCashFlowPaymentsText','Payments','Payments',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Payments', FriendlyName='Payments'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlowPaymentsText' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowCollectionsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryCashFlowCollectionsText','Tahsilatlar','Tahsilatlar',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Tahsilatlar', FriendlyName='Tahsilatlar'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowCollectionsText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlowCollectionsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryCashFlowCollectionsText','Collections','Collections',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Collections', FriendlyName='Collections'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlowCollectionsText' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountHeaderItemText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryRiskAmountHeaderItemText','Ayl�k Ortalama Risk Tutar�','Ayl�k Ortalama Risk Tutar�',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Ayl�k Ortalama Risk Tutar�', FriendlyName='Ayl�k Ortalama Risk Tutar�'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountHeaderItemText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountHeaderItemText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryRiskAmountHeaderItemText','Monthly Average Risk Amount','Monthly Average Risk Amount',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Monthly Average Risk Amount', FriendlyName='Monthly Average Risk Amount'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountHeaderItemText' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountNonCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryRiskAmountNonCashRisksText','Gayrinakit Riskler','Gayrinakit Riskler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gayrinakit Riskler', FriendlyName='Gayrinakit Riskler'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountNonCashRisksText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountNonCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryRiskAmountNonCashRisksText','Non-Cash Risks','Non-Cash Risks',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Non-Cash Risks', FriendlyName='Non-Cash Risks'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountNonCashRisksText' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryRiskAmountCashRisksText','Nakit Riskler','Nakit Riskler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit Riskler', FriendlyName='Nakit Riskler'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountCashRisksText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryRiskAmountCashRisksText','Cash Risks','Cash Risks',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Cash Risks', FriendlyName='Cash Risks'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountCashRisksText' and ChannelId=19 
	end
------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlow.Title' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryCashFlow.Title','Nakit Ak���','Nakit Ak���',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit Ak���', FriendlyName='Nakit Ak���'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlow.Title' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlow.Title' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryCashFlow.Title','Cash Flow','Cash Flow',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else
	begin
			update vpStringResource Set ResourceValue='Cash Flow', FriendlyName='Cash Flow'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlow.Title' and ChannelId=19 
	end

----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmount.Title' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryRiskAmount.Title','Risk Tutar�','Risk Tutar�',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Risk Tutar�', FriendlyName='Risk Tutar�'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmount.Title' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmount.Title' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryRiskAmount.Title','Risk Amount','Risk Amount',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Risk Amount', FriendlyName='Risk Amount'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmount.Title' and ChannelId=19 
	end
----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlow.BottomPanelText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryCashFlow.BottomPanelText','Detaylar','Detaylar',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Detaylar', FriendlyName='Detaylar'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlow.BottomPanelText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlow.BottomPanelText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryCashFlow.BottomPanelText','Details','Details',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else
	begin
			update vpStringResource Set ResourceValue='Details', FriendlyName='Details'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryCashFlow.BottomPanelText' and ChannelId=19 
	end

----------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmount.BottomPanelText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','tr-TR','SummaryRiskAmount.BottomPanelText','Detaylar','Detaylar',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Detaylar', FriendlyName='Detaylar'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmount.BottomPanelText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmount.BottomPanelText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx','en-US','SummaryRiskAmount.BottomPanelText','Details','Details',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else
	begin
			update vpStringResource Set ResourceValue='Details', FriendlyName='Details'
			where ResourceType='WebApplication.UI/Controls/CashFlowAndRiskBalanceControl.ascx' and CultureCode='en-US' and ResourceKey='SummaryRiskAmount.BottomPanelText' and ChannelId=19 
	end
----------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowPaymentsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','SummaryCashFlowPaymentsText','�demeler','�demeler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�demeler', FriendlyName='�demeler'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowPaymentsText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='SummaryCashFlowPaymentsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','SummaryCashFlowPaymentsText','Payments','Payments',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Payments', FriendlyName='Payments'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='SummaryCashFlowPaymentsText' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowCollectionsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','SummaryCashFlowCollectionsText','Tahsilatlar','Tahsilatlar',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Tahsilatlar', FriendlyName='Tahsilatlar'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='SummaryCashFlowCollectionsText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='SummaryCashFlowCollectionsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','SummaryCashFlowCollectionsText','Collections','Collections',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Collections', FriendlyName='Collections'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='SummaryCashFlowCollectionsText' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountNonCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','SummaryRiskAmountNonCashRisksText','Gayrinakit Riskler','Gayrinakit Riskler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gayrinakit Riskler', FriendlyName='Gayrinakit Riskler'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountNonCashRisksText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountNonCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','SummaryRiskAmountNonCashRisksText','Non-Cash Risks','Non-Cash Risks',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Non-Cash Risks', FriendlyName='Non-Cash Risks'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountNonCashRisksText' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','SummaryRiskAmountCashRisksText','Nakit Riskler','Nakit Riskler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit Riskler', FriendlyName='Nakit Riskler'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='SummaryRiskAmountCashRisksText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','SummaryRiskAmountCashRisksText','Cash Risks','Cash Risks',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Cash Risks', FriendlyName='Cash Risks'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='SummaryRiskAmountCashRisksText' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='HeaderTotalPaymentsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','HeaderTotalPaymentsText','Total Amount of Payments','Total Amount of Payments',NULL,'',1,'Apr 12 2021  3:29PM',NULL,NULL,'T64513','Apr 12 2021  3:29PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Total Amount of Payments', FriendlyName='Total Amount of Payments'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='HeaderTotalPaymentsText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='HeaderTotalPaymentsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','HeaderTotalPaymentsText','Toplam �demeler Tutar�','Toplam �demeler Tutar�',NULL,'',1,'Apr 12 2021  3:29PM',NULL,NULL,'T64513','Apr 12 2021  3:29PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Toplam �demeler Tutar�', FriendlyName='Toplam �demeler Tutar�'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='HeaderTotalPaymentsText' and ChannelId=19 
	end
--------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='HeaderTotalCollectionsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','HeaderTotalCollectionsText','Total Amount of Collections','Total Amount of Collections',NULL,'',1,'Apr 12 2021  3:29PM',NULL,NULL,'T64513','Apr 12 2021  3:29PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Total Amount of Collections', FriendlyName='Total Amount of Collections'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='HeaderTotalCollectionsText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='HeaderTotalCollectionsText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','HeaderTotalCollectionsText','Toplam Tahsilatlar Tutar�','Toplam Tahsilatlar Tutar�',NULL,'',1,'Apr 12 2021  3:29PM',NULL,NULL,'T64513','Apr 12 2021  3:29PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Toplam Tahsilatlar Tutar�', FriendlyName='Toplam Tahsilatlar Tutar�'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='HeaderTotalCollectionsText' and ChannelId=19 
	end

------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='HeaderTotalCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','HeaderTotalCashRisksText','Total Amount of Cash Risks','Total Amount of Cash Risks',NULL,'',1,'Apr 12 2021  3:29PM',NULL,NULL,'T64513','Apr 12 2021  3:29PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Total Amount of Cash Risks', FriendlyName='Total Amount of Cash Risks'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='HeaderTotalCashRisksText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='HeaderTotalCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','HeaderTotalCashRisksText','Toplam Nakit Riskler Tutar�','Toplam Nakit Riskler Tutar�',NULL,'',1,'Apr 12 2021  3:29PM',NULL,NULL,'T64513','Apr 12 2021  3:29PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Toplam Nakit Riskler Tutar�', FriendlyName='Toplam Nakit Riskler Tutar�'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='HeaderTotalCashRisksText' and ChannelId=19 
	end

--------------------

if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='HeaderTotalNonCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','HeaderTotalNonCashRisksText','Total Amount of Non-Cash Risks','Total Amount of Non-Cash Risks',NULL,'',1,'Apr 12 2021  3:29PM',NULL,NULL,'T64513','Apr 12 2021  3:29PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Total Amount of Non-Cash Risks', FriendlyName='Total Amount of Non-Cash Risks'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='HeaderTotalNonCashRisksText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='HeaderTotalNonCashRisksText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','HeaderTotalNonCashRisksText','Toplam Gayrinakit Riskler Tutar�','Toplam Gayrinakit Riskler Tutar�',NULL,'',1,'Apr 12 2021  3:29PM',NULL,NULL,'T64513','Apr 12 2021  3:29PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Toplam Gayrinakit Riskler Tutar�', FriendlyName='Toplam Gayrinakit Riskler Tutar�'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='HeaderTotalNonCashRisksText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='TabItemCashFlowPayments.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','TabItemCashFlowPayments.HeaderText','�demeler','�demeler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�demeler', FriendlyName='�demeler'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='TabItemCashFlowPayments.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='TabItemCashFlowPayments.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','TabItemCashFlowPayments.HeaderText','Payments','Payments',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Payments', FriendlyName='Payments'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='TabItemCashFlowPayments.HeaderText' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='TabItemCashFlowCollections.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','TabItemCashFlowCollections.HeaderText','Tahsilatlar','Tahsilatlar',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Tahsilatlar', FriendlyName='Tahsilatlar'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='TabItemCashFlowCollections.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='TabItemCashFlowCollections.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','TabItemCashFlowCollections.HeaderText','Collections','Collections',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Collections', FriendlyName='Collections'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='TabItemCashFlowCollections.HeaderText' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='TabItemRiskAmountNonCashRisks.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','TabItemRiskAmountNonCashRisks.HeaderText','Gayrinakit Riskler','Gayrinakit Riskler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Gayrinakit Riskler', FriendlyName='Gayrinakit Riskler'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='TabItemRiskAmountNonCashRisks.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='TabItemRiskAmountNonCashRisks.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','TabItemRiskAmountNonCashRisks.HeaderText','Non-Cash Risks','Non-Cash Risks',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Non-Cash Risks', FriendlyName='Non-Cash Risks'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='TabItemRiskAmountNonCashRisks.HeaderText' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='TabItemRiskAmountCashRisks.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','TabItemRiskAmountCashRisks.HeaderText','Nakit Riskler','Nakit Riskler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit Riskler', FriendlyName='Nakit Riskler'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='TabItemRiskAmountCashRisks.HeaderText' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='TabItemRiskAmountCashRisks.HeaderText' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','TabItemRiskAmountCashRisks.HeaderText','Cash Risks','Cash Risks',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Cash Risks', FriendlyName='Cash Risks'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='TabItemRiskAmountCashRisks.HeaderText' and ChannelId=19 
	end
------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblCommercialInstallmentLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblCommercialInstallmentLoan','Taksitli Ticari Kredi','Taksitli Ticari Kredi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Taksitli Ticari Kredi', FriendlyName='Taksitli Ticari Kredi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblCommercialInstallmentLoan' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblCommercialInstallmentLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblCommercialInstallmentLoan','Commercial Installment Loan','Commercial Installment Loan',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Commercial Installment Loan', FriendlyName='Commercial Installment Loan'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblCommercialInstallmentLoan' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblRevolvingLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblRevolvingLoan','Rotatif Kredi','Rotatif Kredi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Rotatif Kredi', FriendlyName='Rotatif Kredi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblRevolvingLoan' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblRevolvingLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblRevolvingLoan','Revolving Loan','Revolving Loan',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Revolving Loan', FriendlyName='Revolving Loan'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblRevolvingLoan' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblKobiCashAccount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblKobiCashAccount','Kobi Nakit Hesap','Kobi Nakit Hesap',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kobi Nakit Hesap', FriendlyName='Kobi Nakit Hesap'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblKobiCashAccount' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblKobiCashAccount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblKobiCashAccount','Kobi Cash Account','Kobi Cash Account',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kobi Cash Account', FriendlyName='Kobi Cash Account'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblKobiCashAccount' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblSpotLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblSpotLoan','Spot Kredi','Spot Kredi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Spot Kredi', FriendlyName='Spot Kredi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblSpotLoan' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblSpotLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblSpotLoan','Spot Loan','Spot Loan',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Spot Loan', FriendlyName='Spot Loan'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblSpotLoan' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblDiscountSubsidiaryLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblDiscountSubsidiaryLoan','�skonto/��tira Kredisi','�skonto/��tira Kredisi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�skonto/��tira Kredisi', FriendlyName='�skonto/��tira Kredisi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblDiscountSubsidiaryLoan' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblDiscountSubsidiaryLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblDiscountSubsidiaryLoan','Discount/Subsidiary Loan','Discount/Subsidiary Loan',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Discount/Subsidiary Loan', FriendlyName='Discount/Subsidiary Loan'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblDiscountSubsidiaryLoan' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblDynamicLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblDynamicLoan','Dinamik Kredi','Dinamik Kredi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Dinamik Kredi', FriendlyName='Dinamik Kredi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblDynamicLoan' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblDynamicLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblDynamicLoan','Dynamic Loan','Dynamic Loan',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Dynamic Loan', FriendlyName='Dynamic Loan'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblDynamicLoan' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblLetterOfGuarantee' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblLetterOfGuarantee','Teminat Mektubu','Teminat Mektubu',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Teminat Mektubu', FriendlyName='Teminat Mektubu'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblLetterOfGuarantee' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblLetterOfGuarantee' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblLetterOfGuarantee','Letter Of Guarantee','Letter Of Guarantee',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Letter Of Guarantee', FriendlyName='Letter Of Guarantee'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblLetterOfGuarantee' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblInvoices' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblInvoices','DBS','DBS',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='DBS', FriendlyName='DBS'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblInvoices' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblInvoices' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblInvoices','Invoices','Invoices',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Invoices', FriendlyName='Invoices'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblInvoices' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblLetterOfCredit' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblLetterOfCredit','Akreditif','Akreditif',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Akreditif', FriendlyName='Akreditif'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblLetterOfCredit' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblLetterOfCredit' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblLetterOfCredit','Letter Of Credit','Letter Of Credit',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Letter Of Credit', FriendlyName='Letter Of Credit'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblLetterOfCredit' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblAvalAcceptanceLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblAvalAcceptanceLoan','Aval/Kabul Kredisi','Aval/Kabul Kredisi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Aval/Kabul Kredisi', FriendlyName='Aval/Kabul Kredisi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblAvalAcceptanceLoan' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblAvalAcceptanceLoan' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblAvalAcceptanceLoan','Aval/Acceptance Loan','Aval/Acceptance Loan',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Aval/Acceptance Loan', FriendlyName='Aval/Acceptance Loan'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblAvalAcceptanceLoan' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblExternalWarranty' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','tblExternalWarranty','Harici Garanti','Harici Garanti',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Harici Garanti', FriendlyName='Harici Garanti'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='tblExternalWarranty' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblExternalWarranty' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','tblExternalWarranty','External Warranty','External Warranty',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='External Warranty', FriendlyName='External Warranty'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='tblExternalWarranty' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='CashRisksNotExistsText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','CashRisksNotExistsText.Text','Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir nakit riskiniz bulunmamaktad�r.','Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir nakit riskiniz bulunmamaktad�r.',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir nakit riskiniz bulunmamaktad�r.', FriendlyName='Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir nakit riskiniz bulunmamaktad�r.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='CashRisksNotExistsText.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='CashRisksNotExistsText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','CashRisksNotExistsText.Text','You do not have any cash risks included in the cash flow risk balance calculation.','You do not have any cash risks included in the cash flow risk balance calculation.',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You do not have any cash risks included in the cash flow risk balance calculation.', FriendlyName='You do not have any cash risks included in the cash flow risk balance calculation.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='CashRisksNotExistsText.Text' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='NonCashRisksNotExistsText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','NonCashRisksNotExistsText.Text','Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir gayrinakit riskiniz bulunmamaktad�r.','Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir gayrinakit riskiniz bulunmamaktad�r.',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir gayrinakit riskiniz bulunmamaktad�r.', FriendlyName='Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir gayrinakit riskiniz bulunmamaktad�r.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='NonCashRisksNotExistsText.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='NonCashRisksNotExistsText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','NonCashRisksNotExistsText.Text','You do not have any non-cash risks included in the cash flow risk balance calculation.','You do not have any non-cash risks included in the cash flow risk balance calculation.',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You do not have any non-cash risks included in the cash flow risk balance calculation.', FriendlyName='You do not have any non-cash risks included in the cash flow risk balance calculation.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='NonCashRisksNotExistsText.Text' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblCardTransactions' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblCardTransactions','Kart ��lemleri','Kart ��lemleri',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Kart ��lemleri', FriendlyName='Kart ��lemleri'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblCardTransactions' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblCardTransactions' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblCardTransactions','Card Transactions','Card Transactions',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Card Transactions', FriendlyName='Card Transactions'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblCardTransactions' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblChequePayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblChequePayments','�ek �demeleri','�ek �demeleri',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�ek �demeleri', FriendlyName='�ek �demeleri'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblChequePayments' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblChequePayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblChequePayments','Cheque Payments','Cheque Payments',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Cheque Payments', FriendlyName='Cheque Payments'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblChequePayments' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblInvociesPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblInvociesPayments','DBS �demeleri','DBS �demeleri',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='DBS �demeleri', FriendlyName='DBS �demeleri'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblInvociesPayments' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblInvociesPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblInvociesPayments','Invocies Payments','Invocies Payments',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Invocies Payments', FriendlyName='Invocies Payments'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblInvociesPayments' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblImportVolumeForPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblImportVolumeForPayments','�thalat Hacmi','�thalat Hacmi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�thalat Hacmi', FriendlyName='�thalat Hacmi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblImportVolumeForPayments' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblImportVolumeForPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblImportVolumeForPayments','Import Volume','Import Volume',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Import Volume', FriendlyName='Import Volume'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblImportVolumeForPayments' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblTax' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblTax','Vergi','Vergi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Vergi', FriendlyName='Vergi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblTax' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblTax' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblTax','Tax','Tax',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Tax', FriendlyName='Tax'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblTax' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblSSKPremiumPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblSSKPremiumPayments','SSK Prim �demeleri','SSK Prim �demeleri',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='SSK Prim �demeleri', FriendlyName='SSK Prim �demeleri'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblSSKPremiumPayments' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblSSKPremiumPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblSSKPremiumPayments','SSK Premium Payments','SSK Premium Payments',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='SSK Premium Payments', FriendlyName='SSK Premium Payments'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblSSKPremiumPayments' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblAutomaticBillPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblAutomaticBillPayments','Otomatik Fatura �demesi','Otomatik Fatura �demesi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Otomatik Fatura �demesi', FriendlyName='Otomatik Fatura �demesi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblAutomaticBillPayments' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblAutomaticBillPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblAutomaticBillPayments','Automatic Bill Payments','Automatic Bill Payments',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Automatic Bill Payments', FriendlyName='Automatic Bill Payments'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblAutomaticBillPayments' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblSalaryPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblSalaryPayments','Maa� �deme','Maa� �deme',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Maa� �deme', FriendlyName='Maa� �deme'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblSalaryPayments' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblSalaryPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblSalaryPayments','Salary Payments','Salary Payments',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Salary Payments', FriendlyName='Salary Payments'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblSalaryPayments' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblCashTransactionsForPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblCashTransactionsForPayments','Nakit ��lemler','Nakit ��lemler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit ��lemler', FriendlyName='Nakit ��lemler'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblCashTransactionsForPayments' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblCashTransactionsForPayments' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblCashTransactionsForPayments','Cash Transactions','Cash Transactions',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Cash Transactions', FriendlyName='Cash Transactions'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblCashTransactionsForPayments' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblPOSCollections' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblPOSCollections','POS Tahsilatlar�','POS Tahsilatlar�',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='POS Tahsilatlar�', FriendlyName='POS Tahsilatlar�'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblPOSCollections' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblPOSCollections' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblPOSCollections','POS Collections','POS Collections',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='POS Collections', FriendlyName='POS Collections'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblPOSCollections' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblOtherBankCheques' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblOtherBankCheques','Di�er Banka �ekleri','Di�er Banka �ekleri',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Di�er Banka �ekleri', FriendlyName='Di�er Banka �ekleri'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblOtherBankCheques' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblOtherBankCheques' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblOtherBankCheques','Other Bank Cheques','Other Bank Cheques',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Other Bank Cheques', FriendlyName='Other Bank Cheques'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblOtherBankCheques' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblImportVolumeForCollections' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblImportVolumeForCollections','�thalat Hacmi','�thalat Hacmi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='�thalat Hacmi', FriendlyName='�thalat Hacmi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblImportVolumeForCollections' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblImportVolumeForCollections' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblImportVolumeForCollections','Import Volume','Import Volume',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Import Volume', FriendlyName='Import Volume'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblImportVolumeForCollections' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblInvoicesMainDealer' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblInvoicesMainDealer','DBS Ana Bayi','DBS Ana Bayi',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='DBS Ana Bayi', FriendlyName='DBS Ana Bayi'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblInvoicesMainDealer' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblInvoicesMainDealer' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblInvoicesMainDealer','Invoices Main Dealer','Invoices Main Dealer',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Invoices Main Dealer', FriendlyName='Invoices Main Dealer'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblInvoicesMainDealer' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblSGKIncomingTransfers' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblSGKIncomingTransfers','SGK Transferleri Gelen','SGK Transferleri Gelen',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='SGK Transferleri Gelen', FriendlyName='SGK Transferleri Gelen'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblSGKIncomingTransfers' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblSGKIncomingTransfers' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblSGKIncomingTransfers','SGK Incoming Transfers','SGK Incoming Transfers',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='SGK Incoming Transfers', FriendlyName='SGK Incoming Transfers'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblSGKIncomingTransfers' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblCashTransactionsForCollections' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','tblCashTransactionsForCollections','Nakit ��lemler','Nakit ��lemler',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit ��lemler', FriendlyName='Nakit ��lemler'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='tblCashTransactionsForCollections' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblCashTransactionsForCollections' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','tblCashTransactionsForCollections','Cash Transactions','Cash Transactions',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Cash Transactions', FriendlyName='Cash Transactions'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='tblCashTransactionsForCollections' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentsNotExistsText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','PaymentsNotExistsText.Text','Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir �demeniz bulunmamaktad�r.','Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir �demeniz bulunmamaktad�r.',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir �demeniz bulunmamaktad�r.', FriendlyName='Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir �demeniz bulunmamaktad�r.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='PaymentsNotExistsText.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='PaymentsNotExistsText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','PaymentsNotExistsText.Text','You do not have any payments included in the cash flow risk balance calculation.','You do not have any payments included in the cash flow risk balance calculation.',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You do not have any payments included in the cash flow risk balance calculation.', FriendlyName='You do not have any payments included in the cash flow risk balance calculation.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='PaymentsNotExistsText.Text' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='CollectionsNotExistsText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','CollectionsNotExistsText.Text','Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir tahsilat�n�z bulunmamaktad�r.','Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir tahsilat�n�z bulunmamaktad�r.',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir tahsilat�n�z bulunmamaktad�r.', FriendlyName='Nakit ak��� risk dengesi hesaplamas�na dahil edilen herhangi bir tahsilat�n�z bulunmamaktad�r.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='CollectionsNotExistsText.Text' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='CollectionsNotExistsText.Text' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','CollectionsNotExistsText.Text','You do not have any collections included in the cash flow risk balance calculation.','You do not have any collections included in the cash flow risk balance calculation.',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You do not have any collections included in the cash flow risk balance calculation.', FriendlyName='You do not have any collections included in the cash flow risk balance calculation.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='CollectionsNotExistsText.Text' and ChannelId=19 
	end
--------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='Help.GetCommitmentCommissionAccruePeriodDailySummary.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','Help.GetCommitmentCommissionAccruePeriodDailySummary.Start','You can observe your cash flow risk balance from this menu.','You can observe your cash flow risk balance from this menu.',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='You can observe your cash flow risk balance from this menu.' , FriendlyName='You can observe your cash flow risk balance from this menu.'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='Help.GetCommitmentCommissionAccruePeriodDailySummary.Start' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='Help.GetCommitmentCommissionAccruePeriodDailySummary.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','Help.GetCommitmentCommissionAccruePeriodDailySummary.Start','Bu men�den nakit ak��� risk dengenizi g�zlemleyebilirsiniz.','Bu men�den nakit ak��� risk dengenizi g�zlemleyebilirsiniz.',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bu men�den nakit ak��� risk dengenizi g�zlemleyebilirsiniz.' , FriendlyName='Bu men�den nakit ak��� risk dengenizi g�zlemleyebilirsiniz.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='Help.GetCommitmentCommissionAccruePeriodDailySummary.Start' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='Help.GetCashFlowSummaryTransaction.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','Help.GetCashFlowSummaryTransaction.Start','From this menu, you can observe your total cash flow amount included in your cash flow risk calculation.','From this menu, you can observe your total cash flow amount included in your cash flow risk calculation.',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='From this menu, you can observe your total cash flow amount included in your cash flow risk calculation.' , FriendlyName='From this menu, you can observe your total cash flow amount included in your cash flow risk calculation.'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='Help.GetCashFlowSummaryTransaction.Start' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='Help.GetCashFlowSummaryTransaction.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','Help.GetCashFlowSummaryTransaction.Start','Bu men�den nakit ak��� risk hesaplaman�za dahil edilen toplam nakit ak��� tutar�n�z� g�zlemleyebilirsiniz.','Bu men�den nakit ak��� risk hesaplaman�za dahil edilen toplam nakit ak��� tutar�n�z� g�zlemleyebilirsiniz.',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bu men�den nakit ak��� risk hesaplaman�za dahil edilen toplam nakit ak��� tutar�n�z� g�zlemleyebilirsiniz.' , FriendlyName='Bu men�den nakit ak��� risk hesaplaman�za dahil edilen toplam nakit ak��� tutar�n�z� g�zlemleyebilirsiniz.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='Help.GetCashFlowSummaryTransaction.Start' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='Help.GetRiskAmountSummaryTransaction.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','en-US','Help.GetRiskAmountSummaryTransaction.Start','From this menu, you can observe your total risk amount included in your cash flow risk calculation.','From this menu, you can observe your total risk amount included in your cash flow risk calculation.',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='From this menu, you can observe your total risk amount included in your cash flow risk calculation.' , FriendlyName='From this menu, you can observe your total risk amount included in your cash flow risk calculation.'
			where ResourceType='GeneralResource' and CultureCode='en-US' and ResourceKey='Help.GetRiskAmountSummaryTransaction.Start' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='Help.GetRiskAmountSummaryTransaction.Start' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('GeneralResource','tr-TR','Help.GetRiskAmountSummaryTransaction.Start','Bu men�den nakit ak��� risk hesaplaman�za dahil edilen toplam risk tutar�n�z� g�zlemleyebilirsiniz.','Bu men�den nakit ak��� risk hesaplaman�za dahil edilen toplam risk tutar�n�z� g�zlemleyebilirsiniz.',NULL,'',1,getdate(),NULL,NULL,'T64513',getdate(),NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Bu men�den nakit ak��� risk hesaplaman�za dahil edilen toplam risk tutar�n�z� g�zlemleyebilirsiniz.' , FriendlyName='Bu men�den nakit ak��� risk hesaplaman�za dahil edilen toplam risk tutar�n�z� g�zlemleyebilirsiniz.'
			where ResourceType='GeneralResource' and CultureCode='tr-TR' and ResourceKey='Help.GetRiskAmountSummaryTransaction.Start' and ChannelId=19 
	end
-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','tr-TR','VDAMessageForNotBalancedCashFlowAndRiskAmount','Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.','Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.', FriendlyName='Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='tr-TR' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx','en-US','VDAMessageForNotBalancedCashFlowAndRiskAmount','For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.','For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.', FriendlyName='For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlow.aspx' and CultureCode='en-US' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','tr-TR','VDAMessageForNotBalancedCashFlowAndRiskAmount','Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.','Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.', FriendlyName='Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='tr-TR' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx','en-US','VDAMessageForNotBalancedCashFlowAndRiskAmount','For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.','For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.', FriendlyName='For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/RiskAmount.aspx' and CultureCode='en-US' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19 
	end

-------------------
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlowAndRiskBalanceStatusScreen.aspx' and CultureCode='tr-TR' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlowAndRiskBalanceStatusScreen.aspx','tr-TR','VDAMessageForNotBalancedCashFlowAndRiskAmount','Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.','Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.',NULL,'',1,'Apr  7 2021  3:36PM','user','','T64513','Apr  7 2021  3:36PM','Nov 26 2011 10:44PM','0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.', FriendlyName='Detayl� bilgi i�in l�tfen �ubenizle g�r���n�z veya 0850 222 1 900 numaral� �a�r� Merkezimizi aray�n�z.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlowAndRiskBalanceStatusScreen.aspx' and CultureCode='tr-TR' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19 
	end
if not Exists(select 1 from vpStringResource(nolock) where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlowAndRiskBalanceStatusScreen.aspx' and CultureCode='en-US' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19) 
	begin 
				insert into vpStringResource(ResourceType ,CultureCode,ResourceKey,ResourceValue ,FriendlyName ,TransactionID ,NewResourceValue ,Status ,LastAccessTime ,CheckedBy ,Comment ,ModifyBy ,ModifyDate ,CheckedDate ,IsDeleted ,CategoryID ,ChannelID) 
				values('WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlowAndRiskBalanceStatusScreen.aspx','en-US','VDAMessageForNotBalancedCashFlowAndRiskAmount','For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.','For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.',NULL,'',1,'Apr  7 2021  3:36PM',NULL,NULL,'T64513','Apr  7 2021  3:36PM',NULL,'0',NULL,'19') 
	end 
	else 
	begin
			update vpStringResource Set ResourceValue='For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.', FriendlyName='For detailed information, please contact your branch or call our Call Center at 0850 222 1 900.'
			where ResourceType='WebApplication.UI/Transactions/Loans/CashFlowAndRiskBalance/CashFlowAndRiskBalanceStatusScreen.aspx' and CultureCode='en-US' and ResourceKey='VDAMessageForNotBalancedCashFlowAndRiskAmount' and ChannelId=19 
	end

-------------------