# EspTouch for Android
This APP is used to configure ESP devices to connect target AP, the devices need run smart config.

## Licence
- See [Licence](ESPRESSIF_MIT_LICENSE)

## Version Log
- See [Log](log)

## Releases
- See [releases](https://github.com/EspressifApp/EspRelease/tree/master/EspTouch), contain APK and Jar
- For developer, if you don't want use [esptouch](esptouch) module, download the jar into your own project.