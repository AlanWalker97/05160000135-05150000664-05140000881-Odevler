package com.espressif.iot.esptouch.demo_activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;

import com.espressif.iot_esptouch_demo.R;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;

public class EsptouchDemoActivity extends AppCompatActivity implements OnClickListener {
    private LinearLayout linearLayout;
    private Button sprayBtn;
    private ProgressDialog mProgressDialog;
    private Boolean isConnected;
    private Boolean isActivated;
    private Boolean firstCheck = true;
    private Switch systemInitializerSwitch;
    private AsyncTask<Void, Void, String> ATask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.esptouch_demo_activity);
        systemInitializerSwitch = findViewById(R.id.system_intializer_switch);
        linearLayout = findViewById(R.id.linear_layout);
        systemInitializerSwitch.setOnClickListener(this);
        sprayBtn = findViewById(R.id.spray);
        sprayBtn.setOnClickListener(this);
        sprayBtn.setEnabled(false);
    }

    @Override
    protected void onStart() {
        super.onStart();
        systemInitializerSwitch.setChecked(false);
        sprayBtn.setEnabled(false);
        ATask=new checkConnection(EsptouchDemoActivity.this).execute();
    }

    @Override
    public void onClick(View v) {
        if (v == systemInitializerSwitch) {
            ATask.cancel(true);
            ATask=new switchCommand(EsptouchDemoActivity.this).execute();
        } else if (v == sprayBtn) {
            sprayBtn.setEnabled(false);
            new sprayIt(EsptouchDemoActivity.this).execute();
        }
    }

    @SuppressLint("StaticFieldLeak")
    private class sprayIt extends AsyncTask<Void, Void, String> {

        private WeakReference<EsptouchDemoActivity> mActivity;

        sprayIt(EsptouchDemoActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        protected void onPreExecute() {
            Activity activity = mActivity.get();
            mProgressDialog = new ProgressDialog(activity);
            mProgressDialog.setMessage(activity.getString(R.string.configuring_message));
            mProgressDialog.setCanceledOnTouchOutside(false);
            mProgressDialog.show();
        }

        @Override
        protected String doInBackground(Void... strings) {
            String check;
            try {
                DatagramSocket udpSocket = new DatagramSocket(10801);
                InetAddress serverAddr = InetAddress.getByName("192.168.1.199");
                byte[] buf = ("sprayit").getBytes();
                DatagramPacket sendingPacket = new DatagramPacket(buf, buf.length,serverAddr, 10801);
                udpSocket.send(sendingPacket);
                while (true) {
                    try {
                        byte[] message = new byte[8000];
                        DatagramPacket receivingPacket = new DatagramPacket(message,message.length);
                        Log.i("UDP client: ", "about to wait to receive");
                        udpSocket.setSoTimeout(20000);
                        udpSocket.receive(receivingPacket);
                        check = new String(message, 0, receivingPacket.getLength());
                        receivingPacket.setLength(message.length);
                        if(check.contains("sprayingstarted")){
                            runOnUiThread(new Runnable() {
                                @SuppressLint("SetTextI18n")
                                @Override
                                public void run() {
                                    mProgressDialog.dismiss();
                                    systemInitializerSwitch.setEnabled(false);
                                    sprayBtn.setText(getString(R.string.configure_spraying_text));
                                    linearLayout.setBackgroundColor(Color.GREEN);
                                }
                            });
                        }
                        else if (check.contains("sprayingfinished")) {
                            runOnUiThread(new Runnable() {
                                @SuppressLint("SetTextI18n")
                                @Override
                                public void run() {
                                    sprayBtn.setEnabled(true);
                                    systemInitializerSwitch.setEnabled(true);
                                    sprayBtn.setText(getString(R.string.configure_spray_text));
                                    linearLayout.setBackgroundColor(Color.WHITE);
                                }
                            });
                            udpSocket.close();
                            break;
                        }
                    } catch (IOException e) {
                        Log.e(" e", "error: ", e);
                        udpSocket.close();
                    }
                }
            } catch (IOException e) {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        new checkConnection(EsptouchDemoActivity.this).execute();
                        sprayBtn.setEnabled(false);
                    }
                });
                return null;
            }
            return null;
        }
    }

    private boolean isSwitchChecked(){
        return systemInitializerSwitch.isChecked();
    }

    @SuppressLint("StaticFieldLeak")
    private class checkConnection extends AsyncTask<Void, Void, String> {
        private WeakReference<EsptouchDemoActivity> mActivity;

        checkConnection(EsptouchDemoActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        protected void onPreExecute() {
            sprayBtn.setEnabled(false);
            Activity activity = mActivity.get();
            mProgressDialog = new ProgressDialog(activity);
            mProgressDialog.setMessage(activity.getString(R.string.configuring_message));
            mProgressDialog.setCanceledOnTouchOutside(false);
            mProgressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    cancel(true);
                    if(!firstCheck){
                        systemInitializerSwitch.setChecked(!isSwitchChecked());
                    }
                    firstCheck = false;
                }
            });
            mProgressDialog.setButton(DialogInterface.BUTTON_NEGATIVE, activity.getText(android.R.string.cancel),
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            cancel(true);
                            if(!firstCheck){
                                systemInitializerSwitch.setChecked(!isSwitchChecked());
                            }
                            firstCheck = false;
                        }
                    });
            mProgressDialog.show();
        }

        @Override
        protected String doInBackground(Void... strings) {
            String check;
            isActivated=false;
            try {
                DatagramSocket udpSocket = new DatagramSocket(10801);
                InetAddress serverAddr = InetAddress.getByName("192.168.1.199");
                byte[] buf = ("status").getBytes();
                DatagramPacket sendingPacket = new DatagramPacket(buf, buf.length,serverAddr, 10801);
                udpSocket.send(sendingPacket);
                isConnected = true;
                while (true) {
                    try {
                        byte[] message = new byte[8000];
                        DatagramPacket receivingPacket = new DatagramPacket(message,message.length);
                        Log.i("UDP client: ", "about to wait to receive");
                        udpSocket.setSoTimeout(10000);
                        udpSocket.receive(receivingPacket);
                        check = new String(message, 0, receivingPacket.getLength());
                        receivingPacket.setLength(message.length);
                        udpSocket.close();
                        if (check.contains("deactivated")) {
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    systemInitializerSwitch.setChecked(false);
                                    sprayBtn.setEnabled(false);
                                }
                            });
                            isActivated=false;
                            firstCheck = false;
                            break;
                        }
                        else if (check.contains("activated")) {
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    systemInitializerSwitch.setChecked(true);
                                    sprayBtn.setEnabled(true);
                                }
                            });
                            isActivated=true;
                            firstCheck = false;
                            break;
                        }
                    } catch (IOException e) {
                        Log.e(" e", "error: ", e);
                        isConnected = false;
                        firstCheck = false;
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                systemInitializerSwitch.setChecked(false);
                                sprayBtn.setEnabled(false);
                            }
                        });
                        udpSocket.close();
                    }
                }
            } catch (IOException e) {
                isConnected = false;
                firstCheck = false;
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        systemInitializerSwitch.setChecked(false);
                        sprayBtn.setEnabled(false);
                    }
                });
                return null;
            }
            return null;
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            EsptouchDemoActivity activity = mActivity.get();
            mProgressDialog.dismiss();
            AlertDialog mResultDialog;
            if (isConnected) {
                if(isActivated){
                    ArrayList<CharSequence> resultMsgList = new ArrayList<>();
                    String message = activity.getString(R.string.configure_result_activated_item);
                    resultMsgList.add(message);
                    CharSequence[] items = new CharSequence[resultMsgList.size()];
                    mResultDialog = new AlertDialog.Builder(activity)
                            .setTitle(R.string.configure_result_success)
                            .setItems(resultMsgList.toArray(items), null)
                            .setPositiveButton(android.R.string.ok, null)
                            .show();
                }
                else {
                    ArrayList<CharSequence> resultMsgList = new ArrayList<>();
                    String message = activity.getString(R.string.configure_result_deactivated_item);
                    resultMsgList.add(message);
                    CharSequence[] items = new CharSequence[resultMsgList.size()];
                    mResultDialog = new AlertDialog.Builder(activity)
                            .setTitle(R.string.configure_result_success)
                            .setItems(resultMsgList.toArray(items), null)
                            .setPositiveButton(android.R.string.ok, null)
                            .show();
                }
            } else {
                mResultDialog = new AlertDialog.Builder(activity)
                        .setTitle(R.string.configure_result_success)
                        .setMessage(R.string.configure_result_failed)
                        .setPositiveButton(android.R.string.ok, null)
                        .show();
            }
            mResultDialog.setCanceledOnTouchOutside(false);
        }

    }
    @SuppressLint("StaticFieldLeak")
    private class switchCommand extends AsyncTask<Void, Void, String> {
        private WeakReference<EsptouchDemoActivity> mActivity;

        switchCommand(EsptouchDemoActivity activity) {
            mActivity = new WeakReference<>(activity);
        }

        @Override
        protected void onPreExecute() {
            sprayBtn.setEnabled(false);
            Activity activity = mActivity.get();
            mProgressDialog = new ProgressDialog(activity);
            mProgressDialog.setMessage(activity.getString(R.string.configuring_message));
            mProgressDialog.setCanceledOnTouchOutside(false);
            mProgressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                @Override
                public void onCancel(DialogInterface dialog) {
                    cancel(true);
                    if(!firstCheck){
                        systemInitializerSwitch.setChecked(!isSwitchChecked());
                    }
                    firstCheck = false;
                }
            });
            mProgressDialog.setButton(DialogInterface.BUTTON_NEGATIVE, activity.getText(android.R.string.cancel),
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            cancel(true);
                            if(!firstCheck){
                                systemInitializerSwitch.setChecked(!isSwitchChecked());
                            }
                            firstCheck = false;
                        }
                    });
            mProgressDialog.show();
        }

        @Override
        protected String doInBackground(Void... strings) {
            String check;
            isActivated=false;
            try {
                DatagramSocket udpSocket = new DatagramSocket(10801);
                InetAddress serverAddr = InetAddress.getByName("192.168.1.199");
                byte[] buf;
                if(isSwitchChecked()){
                    buf = ("activate").getBytes();
                }
                else {
                    buf = ("deactivate").getBytes();
                }
                DatagramPacket sendingPacket = new DatagramPacket(buf, buf.length,serverAddr, 10801);
                udpSocket.send(sendingPacket);
                isConnected = true;
                while (true) {
                    try {
                        byte[] message = new byte[8000];
                        DatagramPacket receivingPacket = new DatagramPacket(message,message.length);
                        Log.i("UDP client: ", "about to wait to receive");
                        udpSocket.setSoTimeout(10000);
                        udpSocket.receive(receivingPacket);
                        check = new String(message, 0, receivingPacket.getLength());
                        receivingPacket.setLength(message.length);
                        udpSocket.close();
                        if (check.contains("deactivated")) {
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    systemInitializerSwitch.setChecked(false);
                                    sprayBtn.setEnabled(false);
                                }
                            });
                            isActivated=false;
                            firstCheck = false;
                            break;
                        }
                        else if (check.contains("activated")) {
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    systemInitializerSwitch.setChecked(true);
                                    sprayBtn.setEnabled(true);
                                }
                            });
                            isActivated=true;
                            firstCheck = false;
                            break;
                        }
                    } catch (IOException e) {
                        Log.e(" e", "error: ", e);
                        isConnected = false;
                        firstCheck = false;
                        runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                systemInitializerSwitch.setChecked(false);
                                sprayBtn.setEnabled(false);
                            }
                        });
                        udpSocket.close();
                    }
                }
            } catch (IOException e) {
                isConnected = false;
                firstCheck = false;
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        systemInitializerSwitch.setChecked(false);
                        sprayBtn.setEnabled(false);
                    }
                });
                return null;
            }
            return null;
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            EsptouchDemoActivity activity = mActivity.get();
            mProgressDialog.dismiss();
            AlertDialog mResultDialog;
            if (isConnected) {
                if(isActivated){
                    ArrayList<CharSequence> resultMsgList = new ArrayList<>();
                    String message = activity.getString(R.string.configure_result_activated_item);
                    resultMsgList.add(message);
                    CharSequence[] items = new CharSequence[resultMsgList.size()];
                    mResultDialog = new AlertDialog.Builder(activity)
                            .setTitle(R.string.configure_result_success)
                            .setItems(resultMsgList.toArray(items), null)
                            .setPositiveButton(android.R.string.ok, null)
                            .show();
                }
                else {
                    ArrayList<CharSequence> resultMsgList = new ArrayList<>();
                    String message = activity.getString(R.string.configure_result_deactivated_item);
                    resultMsgList.add(message);
                    CharSequence[] items = new CharSequence[resultMsgList.size()];
                    mResultDialog = new AlertDialog.Builder(activity)
                            .setTitle(R.string.configure_result_success)
                            .setItems(resultMsgList.toArray(items), null)
                            .setPositiveButton(android.R.string.ok, null)
                            .show();
                }
            } else {
                mResultDialog = new AlertDialog.Builder(activity)
                        .setTitle(R.string.configure_result_success)
                        .setMessage(R.string.configure_result_failed)
                        .setPositiveButton(android.R.string.ok, null)
                        .show();
            }
            mResultDialog.setCanceledOnTouchOutside(false);
        }

    }

}